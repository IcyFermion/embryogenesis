# Terminal-cell lineage Pareto analysis

Updated 2026-09-23. This directory contains the complete analysis and
publication pipeline for the terminal-cell portion of the project. This README
is the authoritative module record: it combines the analysis conventions,
figure decisions, reproducible findings, caveats, and production instructions
for Figures 2--6, Figures S1--S3, and Table 1.

The analysis tests whether terminal-cell parentage in nematode embryogenesis is
Pareto optimal with respect to two competing objectives:

- **travel distance**, derived from embryo cell tracking; and
- **cell-state distance**, derived from protein or RNA expression profiles.

Terminal-cell identities, final positions, and molecular states are held fixed.
Alternative lineages are reconstructed by assigning terminal cells to candidate
parents with minimum-cost bipartite matching across a sweep of objective
weights. The primary publication analysis uses *C. elegans* protein expression
and embryo-1 tracking. Comparative analyses cover RNA expression, tracking
replicates, subtrees, two-dimensional tracking, z-noise controls, edge
perturbations, and random-feature controls.

## Publication status

**Workspace navigation and housekeeping:** see
[WORKSPACE_STATUS.md](WORKSPACE_STATUS.md) for current figure entrypoints,
active dependencies, paused pilots, and the checksummed local archive of
superseded prototypes. The current S3 renderer retains its historical
`prototype_tracking_cross_geometry.py` name and remains a build dependency.

**Direction selected 2026-09-20:** adopt normalized pooled travel for the
primary terminal-only analysis, with minimax retained as sensitivity evidence.
The accompanying presentation change uses endpoint-normalized coordinates for
suitable Pareto front panels, retaining percentage and null-relative views
where they answer different questions. Display normalization is independent
of the optimization's objective scaling and weight grid.
The compatibility-preserving implementation described in
[POOLED_TRAVEL_MIGRATION_PLAN.md](POOLED_TRAVEL_MIGRATION_PLAN.md) is complete
as an isolated candidate. It regenerates Figures 2--6, Figures S1--S3, and
Table 1 from the pooled profile without writing to accepted output paths.
The current released configuration below remains embryo 1 until the candidate
receives normal figure/manuscript review and is promoted as one coordinated
bundle. Existing no-argument single-embryo entrypoints remain reproducible.

The candidate is in
`output/runs/pooled_tracking_v1/migration_candidate_20260920/`. Its validation
report separates legacy embryo 1 (299 edges, 43 subtrees), matched embryo 1
(275, 42), and pooled travel (275, 42). All migration checks pass, including
exact legacy matrix/front reproduction, pooled reconstruction, cache/display
isolation, endpoint inversion, panel completeness, and the preserved baseline
archive. Natural lineage occurs on the sampled front in 16, 15, and 27
subtrees, respectively; this comparison is descriptive and is not the reason
pooling was selected.

**Candidate presentation revision, 2026-09-21 (superseded layout):** the endpoint-coordinate
schematic moves to Figure 2A above the pooled front in Figure 2B. Figure 5
now contains only the major-subtree and all-subtree summaries as panels A--B
and refers back to Figure 2A. In the schematic, (P^*) is the closest attained
sampled-front assignment used by the canonical metrics; the highlighted point
in Figure 2B is instead the maximum-natural-edge-retention assignment. They are
not generally the same assignment. This rearrangement applies only to the
isolated pooled candidate; accepted legacy panel names and wrappers remain
unchanged.

**Second review revision, 2026-09-22 (superseded layout):** Figure 2A was centered at 68% text
width above a full-width Figure 2B, making its labels roughly twice as large
as in the earlier side-by-side draft. Figure 3 again includes the existing
null-model schematic as panel A above pooled structural panels B--C. Figure 4
subtree summaries and Figure 5 canonical metrics now have dedicated identity
manifests. Both renderers validate the existing context manifest, requested
configuration, cohort, and file hashes before reading a table or rewriting
run provenance.

**Organization integration, 2026-09-22:** the isolated candidate now has a
standalone Figure 1 endpoint-coordinate amendment, pending co-author
integration, and a single full-width Figure 2 front without a panel letter.
Figure 5 contains only the two subtree summaries and refers to the amendment.
Figure 3A remains in its wrapper. Candidate Figure S3 uses the selected
one-page, four-geometry 2-by-2 comparison, with full fronts and a near-natural
inset in every panel. Each target geometry evaluates all four assignment
sources under one target-native endpoint transform. The earlier three- and
two-panel layouts remain review-only prototypes; see
[PUBLICATION_ORGANIZATION_PROTOTYPE.md](PUBLICATION_ORGANIZATION_PROTOTYPE.md).

The compiled candidate wrappers and directly included assets are in
`output/runs/pooled_tracking_v1/migration_candidate_20260920/publication/endpoint/`.
Key files are `fig1_ce_endpoint_normalization_amendment.pdf`,
`fig2_ce_terminal_pareto_main.pdf`, and
`figS3_ce_tracking_robustness.pdf`; the S3 component has a vector PDF,
PNG, editable-text SVG, `cross_geometry_coordinates.csv`, and `provenance.json`.
Use `publication_build.py` with `--profile pooled_tracking_v1`,
`--run-id migration_candidate_20260920`, and `--layout-only` to rebuild from the
validated numerical caches without rewriting them. The historical source
assignments are retained in the tracking-sensitivity cache, while the candidate
publication records their hashes and every projected coordinate. Accepted
publication files and the co-author's Figure 1 artwork remain untouched.

The organization checkpoint and pre-build SHA-256 manifests are under
`validation/organization_checkpoint_20260922/` in that same run. All 29
checks in `validation/migration_validation.md` pass: the 4,816 S3
target/source/sweep coordinates replay against saved assignments (maximum
absolute difference (4.55\times10^{-13})); analysis caches, tracking
sensitivity inputs, and accepted publication assets match their checkpoint
hashes. All candidate wrappers compiled as single-page PDFs and were inspected
at manuscript size. This is a validated candidate, not an accepted release.

**Figure S3 layout refinement, 2026-09-23:** its two shared keys now occupy
separate source-color and line/marker rows above the panels, with additional
space before the A/B titles. The compiled one-page wrapper was re-inspected at
manuscript size. The projection-table and assignment hashes are unchanged;
the legend revision changes only the rendered asset and renderer-source hash.

The selected manuscript outputs are release candidates. They have dedicated
renderers, split panel assets where appropriate, standalone LaTeX wrappers, and
compiled one-page PDFs.

| Item | Role | TeX/PDF stem | LaTeX label |
|---|---|---|---|
| Candidate Figure 1 amendment | Endpoint coordinates and canonical metrics; co-author integration pending | `fig1_ce_endpoint_normalization_amendment` | `ce_endpoint_normalization_amendment` |
| Figure 2 | Terminal Pareto front and null models | `fig2_ce_terminal_pareto_main` | `ce_terminal_pareto_main` |
| Figure 3 | Null schematic and structural support | `fig3_ce_terminal_pareto_supporting` | `ce_terminal_pareto_supporting` |
| Figure 4 | Investigated-subtree lineage map | `fig4_ce_subtree_map` | `ce_subtree_map` |
| Figure 5 | Canonical subtree proximity summary | `fig5_ce_canonical_summary` | `ce_canonical_summary` |
| Figure 6 | Cell-type retention and restricted fronts | `fig6_ce_cell_types` | `ce_cell_types` |
| Figure S1 | Cousin-null-relative sensitivity | `figS1_ce_canonical_summary_cousin_r` | `ce_canonical_summary_cousin_r` |
| Figure S2 | Cell-type endpoint cost ledger | `figS2_ce_cell_type_cost_gain` | `ce_cell_type_cost_gain` |
| Figure S3 | Accepted: three-replicate robustness; pooled candidate: four-geometry transfer | `figS3_ce_tracking_robustness` | `ce_tracking_robustness` |
| Table 1 | Per-subtree statistics | `table1_ce_subtree_statistics` | `ce_subtree_statistics` |

The repository-level `PUBLICATION_FIGURES_HANDOFF.md` records the transition
from this completed module to the next publication analysis.

## Fixed legacy-release analysis conventions

The still-accepted Figures 2--6 configuration is:

- *C. elegans* embryo 1, three-dimensional tracking through `T <= 255`;
- top-20 protein features with cosine cell-state distance;
- terminal cells only;
- first-cousin assignment shuffling with seed 42 as the main null;
- at least 12 usable biological terminal cells per subtree, giving 43 nested
  investigated subtrees; and
- a 300-weight Pareto sweep for the established publication pipeline.

Figures 2--3 additionally show second-cousin, third-cousin, and full-random
assignment shuffles. The superseded 2014 *C. briggsae* tracking series
(`1407...`) is excluded from final replicate comparisons.

Travel and cell-state costs are reported in standard-deviation units from the
first-cousin-shuffle null distribution where a common embryo-wide scale is
needed. In Figures 2--3, displayed coordinates are translated so the natural
lineage is at `(0, 0)`. Translation changes only the presentation origin; it
does not change assignments, fronts, rankings, or relative-Pareto statistics.

Subtree null means, variances, and covariance are computed in closed form.
Random draws are used only for displayed null clouds and for optimality
frequencies when exact enumeration is infeasible. A non-positive null standard
deviation raises before division.

## Canonical subtree metrics

For each subtree, let `T*` be its travel-minimizing assignment, `S*` its
cell-state-minimizing assignment, and `L` its natural assignment. The two
objectives are normalized separately using only the endpoint spans:

\[
D_1(a)=\frac{T(a)-T(T^*)}{T(S^*)-T(T^*)},\qquad
D_2(a)=\frac{S(a)-S(S^*)}{S(T^*)-S(S^*)}.
\]

The natural-lineage distance to the sampled front is

\[
d_{LP}(L)=\min_{p\in\mathcal P_{\mathrm{sampled}}}
\left\|D(L)-D(p)\right\|_2.
\]

The minimum is evaluated over actual sampled assignments, never an interpolated
segment. Coordinates are not clipped to the endpoint box. The canonical
position `u_L` is normalized arc length along the front, from the travel
optimum (`u=0`) to the cell-state optimum (`u=1`), evaluated at the same nearest
assignment.

The endpoint-normalized distance from the first-cousin null mean `N` to that
selected assignment `P*` is

\[
d_{NP}=\left\|D(N)-D(P^*)\right\|_2.
\]

The older cousin-relative statistic `r` uses separately null-standardized
geometry. It is a sensitivity measure, not a scale factor: `d_NP * r` must not
be asserted to equal `d_LP`. Table 1 retains both metrics; Figure 5 uses
`d_LP`/`d_NP`, while Figure S1 shows `r`.

## Figure records

### Figures 2--3: global terminal-cell analysis

Figure 2 shows the global Pareto front, natural assignment, and increasingly
permissive null models. The full-random cloud remains in an inset because it
lies far from the biologically relevant range. In the pooled candidate, the
endpoint-coordinate definition is a separate Figure 1 amendment awaiting
co-author integration; Figure 2 is one full-width front. Full-random inset
padding is a fixed fraction of its displayed data range rather than a
carryover from legacy null-SD coordinates.

Figure 3B uses mean lineage-tree distance among changed edges. The all-edge
definition remains a diagnostic mode, not a publication panel. Figure 3C
reports the structural price of pursuing the last 5% of attainable distance
reduction from the maximum-edge-retention compromise toward either
single-objective endpoint.

Principal structural metrics are:

- **edge retention:** fraction of natural terminal parent--child edges
  preserved;
- **mean lineage-tree distance:** mean tree separation between natural and
  reconstructed parent assignments;
- **TWER:** tree-distance-weighted edge retention; and
- **local perturbation tests:** pair and triple edge swaps that test whether
  both objectives can be improved near the natural lineage.

### Figure 4: investigated-subtree map

Figure 4 places all 43 qualifying subtrees in lineage order, with P0 at the
top. Each pie summarizes the fate composition of the exact usable terminal set
used in that subtree's Pareto analysis. Radius scales with `sqrt(n)`. A solid
circumference means the natural assignment occurs on the sampled front; a
dashed circumference means it does not. Edges connect each displayed subtree
to its nearest qualifying descendant, and non-qualifying nodes are omitted.
Subtree names and cell counts use sequential blue to encode maximum natural-edge
retention. The accepted layout has no measured label collisions.

### Figure 5, Figure S1, and Table 1: canonical subtree summary

Figure 5A defines `u`, `d_LP`, and `d_NP`. Figure 5B reports `d_LP` and `d_NP`
for P0, AB, ABa, ABp, and P1. Figure 5C places all 43 subtrees in `(u, d_LP)`
space and overlays the five major-subtree `d_NP` references. Larger subtrees
receive higher z-order so major lineages are not hidden by smaller markers.
Maximum edge retention is deliberately omitted so each marker communicates
canonical position and proximity only; retention remains in Figures 2--4 and
6 and in Table 1.

Figure S1 preserves cousin-relative `r` as a null-model sensitivity analysis.
Across the 43 subtrees, `d_LP` and `r` have Spearman correlation 0.95, so the
broad proximity ranking does not depend on the first-cousin normalization.

For the pooled candidate, the former Figure 5A schematic is a standalone
Figure 1 amendment. The major-subtree summary becomes Figure 5A and the
all-subtree summary becomes Figure 5B; their metrics and underlying caches
are unchanged.

### Figure 6 and Figure S2: terminal cell types

Cell types are loaded from `data/2023-06-29_entropy_cell_key_V2.csv`, joined on
`wormweb.lineage`, and consolidated with `MERGE_MAP`. The 32 terminal cells
absent from that key exactly match `data/apoptotic_cells.txt` and are typed as
programmed death. The separately annotated dying tail hypodermal cells
`ABplppppppa` and `ABprppppppa` remain distinct and enter the displayed
`other (n<=4)` group.

Figure 6A shows natural-edge retention by terminal fate across all 145 distinct
assignments observed along the global Pareto sweep. Biological parent identity
defines retention, so swapping assignment slots belonging to the same parent
retains both natural edges. Weighted cell-type retention is asserted to
recompose the global curve exactly at every cached assignment. The accepted
maximum-retention assignment has global retention 0.819398. Irregular front
positions are resampled to a uniform canonical-position grid and narrowly
averaged for display only; exact assignments, keypoints, and statistics remain
unsmoothed.

Figures 6B--C repeat the optimization after forbidding assignments across
terminal cell-type groups. Six sufficiently large types receive individual
fronts in shared embryo-wide first-cousin-null standard-deviation units per
cell. This null supplies a common scale only; assignments are constrained by
cell type, not cousin relationships. The aggregate type-preserving front is
then compared with the unrestricted front. At the corresponding
single-objective endpoints, type restriction retains 3.101 standard deviations
more travel distance and 15.073 standard deviations more cell-state distance.
It realizes 16.8% of the unrestricted travel saving and 63.0% of the
unrestricted cell-state saving.

The no-profile Figure 6B--C command retains the accepted null-SD display.
Endpoint coordinates are opt-in via `--display endpoint` and are requested
explicitly by the pooled publication coordinator. Figure 6A/S2 reusable caches
carry a separate identity manifest with profile/context key, sweep resolution,
cohort size, and file hashes; reuse is rejected before any cached table is read
or provenance is rewritten when those fields differ.

Figure S2 is the complementary endpoint ledger: signed per-cell travel and
cell-state changes at the travel optimum, maximum-retention compromise, and
cell-state optimum. The objectives remain on separate axes and are never
combined linearly.

### Figure S3: three-replicate tracking robustness

Figure S3 is generated independently of the accepted Figures 2--6 pipeline.
Numerical time points are not equated across embryos because developmental
timing differs. The analysis retains the predefined stage-matched cutoffs and
constructs a strict intersection of natural terminal parent--child edges. Both
the terminal and its natural parent must be tracked and have the fixed protein
representation.

| Replicate | Cutoff | Usable terminal edges | Strictly matched | Retained |
|---|---:|---:|---:|---:|
| embryo 1 | 255 | 299 | 275 | 92.0% |
| embryo 2 | 247 | 301 | 275 | 91.4% |
| embryo 3 | 225 | 298 | 275 | 92.3% |

The matched set leaves 42 qualifying subtrees at `n >= 12`. All replicates use
the same 275 edges, top-20 protein features, cosine cell-state distance,
first-cousin shuffle with seed 42, exact null moments, 1,000 displayed null
draws, and a 300-interval endpoint-inclusive sweep containing 301 weights.

Panel A overlays the matched P0 fronts in replicate-specific
first-cousin-null-SD coordinates, with each natural lineage translated to the
origin. Panel B reports `u_L`, `d_LP`, and maximum edge retention for P0, AB,
ABa, ABp, and P1. Equal-length horizontal marks are centered on each subtree's
categorical position, match the replicate colors in Panel A, and use uniform
transparency so coincident values visibly blend. Marker shape does not encode
replicate identity. `d_NP` remains cached but is omitted from the panel.

The fronts are closely aligned globally. For P0, replicate ranges are 0.009
for `u_L`, 0.016 for `d_LP`, and 0.044 for maximum edge retention. ABa shows
the largest local spread: 0.127 for `u_L`, 0.054 for `d_LP`, and 0.156 for
maximum edge retention. The largest `d_NP` spread is instead P1 at 0.042. The
result supports global tracking robustness while preserving genuine local
replicate dependence; it does not establish that every subtree is replicate
invariant.

The matching decision is recorded in:

- `output/ce_tracking_replicate_cell_manifest.csv`;
- `output/ce_tracking_replicate_audit.csv`; and
- `output/ce_tracking_replicate_subtree_manifest.csv`.

The remaining S3 caches are `ce_tracking_replicate_fronts.csv`,
`ce_tracking_replicate_null_clouds.csv`, and
`ce_tracking_replicate_major_metrics.csv`.

### Tracking geometry propagated through terminal assignments

The original geometry-transfer backlog has a reproducible global-P0
investigation in `TRACKING_GEOMETRY_SENSITIVITY.md`. It supersedes the earlier
read-only estimates for interpretation: biological parent identity, rather
than duplicate slot identity, defines agreement. Across 301 matched weights,
median biological-parent agreement is 75.6--78.9%, falling to 49.1--56.0% at
the travel endpoint; ten-nearest-parent overlap averages 78.7--79.5%.

All six transferred travel endpoints lose essentially all of their travel
saving over the target natural lineage. Joint optimization nevertheless finds
common assignments with modest improvement in both objectives across all
three geometries. With no increase in cell-state cost, travel savings are
2.41%, 2.32%, and 2.28%; with at least 1% cell-state improvement they are
1.51%, 1.49%, and 1.47%. Optimality is conditional on the documented minimax
criterion and solver tolerances; it is not held-out biological validation.

**Paused for manuscript writing on 2026-09-16.** The author considers the
underlying investigation sufficient for now, while S3 presentation and the
manuscript narrative remain unfinished. The record separates completed P0
results from remaining cell-set, subtree, and held-out sensitivity work.

## Reproducible biological findings

1. The natural terminal assignment is exactly sampled-Pareto-optimal in 16 of
   43 investigated subtrees, all with at most 35 terminal cells. Exact recovery
   becomes less frequent among larger subtrees, but continuous size
   relationships are modest: size versus on-front status has Spearman rho
   `-0.35`, versus front proximity `+0.30`, versus cousin-relative distance
   `+0.18`, and versus maximum retention `-0.06`.
2. Exact recovery is not explained by small assignment spaces. Full-random
   assignments are on the front in 0/1000 draws for every subtree. The
   cousin-shuffle fraction is usually zero and reaches 33% only in the small,
   exactly enumerable MSpa assignment space.
3. Apparent relationships between attainable reductions and subtree depth or
   fate diversity disappear after per-cell normalization (`|rho| < 0.2`).
   Subtree size and median depth are strongly confounded (`rho = 0.90`).
4. True-sibling contrasts are at chance level: 8 of 14 informative pairs agree
   with the proposed direction, with three distance ties excluded.
5. Per-cell endpoint contributions differ by fate. Programmed-death cells have
   the largest cell-state improvement at the cell-state optimum
   (`-0.25 sigma/cell`); epithelium pays the largest travel price there
   (`+0.47 sigma/cell`); muscle pays the largest cell-state price at the travel
   optimum (`+0.22 sigma/cell`). Neurons dominate totals primarily because
   they are abundant.

## Interpretation and statistical caveats

- Nested subtrees are descriptive observations, not independent replicates.
  EMS/MS, ABplpp/ABplppp, and ABprpp/ABprppp can share identical cousin-group
  terminal sets and therefore identical null moments.
- Do not report regression p-values that treat the 43 subtree points as
  independent.
- `d_LP` is an endpoint-normalized geometric display statistic, not a
  biological weighted sum of travel and cell-state distances.
- Cousin-relative `r` is a two-dimensional Euclidean distance in separately
  null-standardized axes, not a conventional one-dimensional z-score.
- Equal weighting of standardized objectives must not be described as a
  biologically balanced cost; the objectives are not linearly comparable.
- Within-type cell-state gains are not uniformly negligible. Attributing them
  to expression noise requires an independent replicate or stability analysis.

## Shared visual semantics

- sequential blue: natural-edge retention;
- teal: travel direction or travel-minimizing assignment;
- vermillion: cell-state direction or cell-state-minimizing assignment;
- charcoal or neutral gray: canonical position `u` and tree geometry;
- purple: natural-lineage-to-front distance `d_LP`;
- gold: first-cousin null and `d_NP`;
- warm earth-tone sequence: ordered null-model family; and
- local categorical colors: cell types or replicates, always identified in the
  panel or legend.

Use sentence case for axes, keep the natural-lineage cross visually dominant,
label every displayed null, and use PDF as the canonical output.

## Code and output layout

```text
terminal_pareto/
├── README.md                              # This authoritative module record
├── analysis_context.py                    # Profiles, provenance, and run paths
├── front_coordinates.py                   # Pure display-coordinate transforms
├── global_analysis.py                     # Profile-keyed global cache
├── publication_build.py                   # Coordinated isolated candidate build
├── publication_wrappers.py                # Run-specific candidate wrappers
├── validate_pooled_migration.py           # Three-profile migration report
├── test_analysis_context.py               # Focused identity/regression suite
├── data_loader.py                         # Tracking, expression, and lineage I/O
├── pareto_engine.py                       # Assignment and null-model methods
├── lineage_metrics.py                     # Retention and tree-distance metrics
├── plot_style.py                          # Shared publication style
├── main.py                                # Complete Marimo analysis notebook
├── subtree_analysis.py                    # Per-subtree summaries and exact nulls
├── subtree_explore.py                     # Cell-type decomposition helpers
├── fig2_fig3_ce_terminal_pareto.py        # Figures 2--3
├── fig4_ce_subtree_map.py                 # Figure 4
├── fig5_table1_ce_canonical_metrics.py    # Figure 5 metrics and Table 1
├── fig5_figs1_ce_canonical_summary.py     # Figure 5 and Figure S1
├── fig6a_figs2_ce_cell_types.py           # Figure 6A and Figure S2
├── fig6bc_ce_within_type.py               # Figure 6B--C
├── figS3_ce_tracking_robustness.py        # Figure S3
└── output/
    ├── runs/                              # Profile/run-isolated candidates
    ├── ce_protein/                        # Configuration diagnostics
    ├── ce_rna/
    ├── cb_rna/
    └── publication/                       # Panels, wrappers, and final PDFs
```

Generated output is ignored by Git. Publication TeX wrappers are intentionally
versioned because they contain captions and layout, so a new ignored wrapper
requires `git add -f`. Do not restore abandoned layouts, combined pre-split
canvases, or threshold-test caches unless a new analysis question needs them.

Accepted component stems in `output/publication/` are:

- Figure 2: `fig2_ce_terminal_pareto_front`;
- Figure 3: `fig3A_ce_null_models`,
  `fig3B_ce_edge_retention_tree_distance`, and
  `fig3C_ce_structural_retention`;
- Figure 4: `fig4_ce_subtree_map_panel`;
- Figure 5: `fig5A_ce_canonical_definition`,
  `fig5B_ce_canonical_major_subtrees`, and
  `fig5C_ce_canonical_all_subtrees`;
- Figure 6: `fig6A_ce_retention_heatmap`,
  `fig6B_ce_within_type_fronts`, and
  `fig6C_ce_type_restricted_aggregate`;
- Figure S1: `figS1A_ce_cousin_r_definition`,
  `figS1B_ce_cousin_r_major_subtrees`, and
  `figS1C_ce_cousin_r_all_subtrees`;
- Figure S2: `figS2_ce_cell_type_cost_gain_panel`; and
- Figure S3: `figS3A_ce_tracking_replicate_fronts` and
  `figS3B_ce_tracking_replicate_metrics`.

The isolated pooled candidate intentionally overrides the Figure 2/5 component
mapping: Figure 2 uses `fig2A_ce_endpoint_coordinate_schematic` plus
`fig2_ce_terminal_pareto_front`, while Figure 5 uses
`fig5A_ce_canonical_major_subtrees` and
`fig5B_ce_canonical_all_subtrees`. Figure 3 retains
`fig3A_ce_null_models` above its pooled panels B--C.

Authoritative numerical caches in `output/` are:

- `subtree_summary_min12.csv`;
- `ce_subtree_canonical_metrics.csv` and
  `ce_subtree_canonical_curves.npz`;
- `global_front_retention_by_cell_type.csv` and
  `global_front_by_cell_type.csv`;
- `within_type_fronts.csv`, `within_type_summary.csv`, and
  `type_preserving_aggregate_front.csv`; and
- the six `ce_tracking_replicate_*.csv` files listed in the Figure S3 section.

## Regeneration

Run from the repository root using the `dev` Conda environment:

For the complete pooled candidate, including downstream figures and wrapper
sources:

```bash
python terminal_pareto/publication_build.py \
  --profile pooled_tracking_v1 \
  --run-id migration_candidate_20260920 \
  --no-compile
python terminal_pareto/test_analysis_context.py
python terminal_pareto/validate_pooled_migration.py \
  --run-id migration_candidate_20260920
```

Remove `--no-compile` when a supported TeX engine is available. The candidate
run writes only below its profile/run directory. The commands below retain
their historical no-argument legacy behavior and accepted output locations.

```bash
env MPLCONFIGDIR=/tmp/embryogenesis_mpl_cache conda run -n dev \
  python terminal_pareto/fig2_fig3_ce_terminal_pareto.py
env MPLCONFIGDIR=/tmp/embryogenesis_mpl_cache conda run -n dev \
  python terminal_pareto/subtree_analysis.py --min-cells 12
env MPLCONFIGDIR=/tmp/embryogenesis_mpl_cache conda run -n dev \
  python terminal_pareto/fig4_ce_subtree_map.py --min-cells 12
env MPLCONFIGDIR=/tmp/embryogenesis_mpl_cache conda run -n dev \
  python terminal_pareto/fig5_table1_ce_canonical_metrics.py --min-cells 12
env MPLCONFIGDIR=/tmp/embryogenesis_mpl_cache conda run -n dev \
  python terminal_pareto/fig5_figs1_ce_canonical_summary.py
env MPLCONFIGDIR=/tmp/embryogenesis_mpl_cache conda run -n dev \
  python terminal_pareto/fig6a_figs2_ce_cell_types.py --iteration 300
env MPLCONFIGDIR=/tmp/embryogenesis_mpl_cache conda run -n dev \
  python terminal_pareto/fig6bc_ce_within_type.py --iteration 300
env MPLCONFIGDIR=/tmp/embryogenesis_mpl_cache conda run -n dev \
  python terminal_pareto/figS3_ce_tracking_robustness.py
```

For the complete notebook analysis, run `python terminal_pareto/main.py`; use
`marimo edit terminal_pareto/main.py` for an interactive session.

Compile wrappers from `terminal_pareto/output/publication/`:

```bash
for stem in \
  fig2_ce_terminal_pareto_main \
  fig3_ce_terminal_pareto_supporting \
  fig4_ce_subtree_map \
  fig5_ce_canonical_summary \
  fig6_ce_cell_types \
  figS1_ce_canonical_summary_cousin_r \
  figS2_ce_cell_type_cost_gain \
  figS3_ce_tracking_robustness \
  table1_ce_subtree_statistics
do
  conda run -n dev tectonic "${stem}.tex"
done
```

## Validation before handoff or commit

1. Run `python -m py_compile` on every changed Python source.
2. Run the canonical self-test:
   `conda run -n dev python terminal_pareto/fig5_table1_ce_canonical_metrics.py --min-cells 12 --selftest`.
3. Regenerate each changed renderer and inspect its PNG/PDF output.
4. Compile each affected standalone wrapper with Tectonic.
5. Run `git diff --check` and inspect `git status --short`.
6. Confirm no unrelated files or expensive full-tree caches are staged.

Python dependencies are defined in `environment.yml`. Tectonic compiles the
standalone publication figures.

## Cross-dataset terminal pilot (2026-09-09)

`pilot_cross_dataset.py` implements an unnumbered comparison of C. elegans
protein, C. elegans RNA, and two AF16 C. briggsae RNA/tracking configurations
on 188 shared terminal edges. See `PILOT_CROSS_DATASET.md` for findings,
endpoint tie handling, regeneration, and calibration/provenance limitations.
The four-page review and caches are in `output/pilot_cross_dataset/`.
This pilot includes existing-3D and XY-only views plus coverage and cell-set
sensitivities; it is not an accepted publication figure.

Paused by author request on 2026-09-14. The pilot record includes the review
clarifications (coverage is not edge retention), the CE depth diagnostic,
validation status, and an ordered resume checklist. Preserve the current
ignored output directory before rerunning; generated plots/caches are local,
not included in the source commit. No publication promotion is authorized.

## CE tracking-variance amendment candidate (checkpoint 2026-09-16)

The CE-only investigation and common-assignment results are documented in
`TRACKING_GEOMETRY_SENSITIVITY.md`. The two-page Figure S3 amendment candidate
is `output/tracking_s3_amendment/figS3_ce_tracking_amended_review.pdf`.
It retains the global-front and subtree evidence from panels A--B and adds
biological-parent agreement,
neighborhood overlap, directed transfer penalties, and common assignments
that improve both objectives across all three tracking geometries.
The 2026-09-16 revision adds three zooms to candidate panel A showing those
common assignments directly below and to the left of the natural lineage
in each embryo's own cost space.
The author chose to keep this figure C. elegans only; the AF16 extension was
stopped. Accepted publication outputs are unchanged. The candidate renderer
and caption are `figS3_ce_tracking_variance_amendment.py` and
`figS3_ce_tracking_variance_amendment.tex`; regeneration and validation details
are in the investigation record. The author has explicitly deferred further
presentation work while drafting the manuscript. Rendering and numerical
validation do not mean the layout, caption, or narrative has been accepted.
Source is committed; generated caches, assignments, and figures remain local
and Git-ignored. Preserve them before resuming analysis or rendering.

On 2026-09-17 the author requested a targeted update to the earlier
`output/tracking_geometry_sensitivity/tracking_geometry_review.pdf`.
It now overlays the three certified common assignments on the cross-evaluated
fronts and adds three zooms showing travel reductions of 1.47--2.41% with
cell-state costs below natural lineage in all three embryos. These three
solutions sample the consensus trade-off; they do not enumerate its full
Pareto front. Regenerate this cache-only review figure with
`python terminal_pareto/plot_tracking_geometry_consensus.py`. The previous
PDF/PNG are preserved in `before_consensus_overlay/` beside the updated figure;
reproduction and validation details are in `TRACKING_GEOMETRY_SENSITIVITY.md`.

The subsequent 2026-09-17 request expanded the consensus analysis across the
full endpoint-to-endpoint trade-off. `common_tracking_front.py` sweeps 301
global cell-state budgets plus extra near-natural budgets, minimizing the
worst travel/natural-travel ratio across the three embryos. It retains actual
shared assignments, optimality bounds, and solver status for every solve.
The dense curve remains a sampled front rather than an enumeration of every
discrete Pareto solution; its projections need not lie on individual fronts.
The completed sweep has 319 certified solves and 296 distinct nondominated
sampled assignments; 24 improve both costs in all three embryos.

To reproduce the current dense review figure:

```bash
python terminal_pareto/common_tracking_front.py --intervals 300 --seconds 10
python terminal_pareto/plot_tracking_geometry_consensus.py \
  --dense-front terminal_pareto/output/common_tracking_assignment/dense_front
```

The renderer also writes
`output/tracking_geometry_sensitivity/consensus_objective_front.pdf`, showing
the consensus objectives directly in percentage changes from natural lineage.
The previous three-point figure is preserved in `before_dense_consensus/`.
This targeted expansion leaves accepted publication assets unchanged.

## Candidate main travel metrics: pooled versus minimax (2026-09-18)

The author requested comparison of both ensemble routes as possible primary
terminal-only travel metrics. `TRACKING_METRIC_COMPARISON.md` records the
definitions, complete results, validation, and adoption consequences.
The review is
`output/tracking_metric_comparison/tracking_metric_comparison_review.pdf`.

Both methods were evaluated at 319 identical cell-state budgets, with all
final solves certified. Pooling minimizes the mean of the three
travel/natural-travel ratios; minimax minimizes their maximum. At no increase
in state cost, pooling reduces mean travel by 2.984% but increases travel by
0.127% in its worst embryo. Minimax reduces travel by at least 2.276% in all
three. Each method improves held-out travel in only two of 12 tested
leave-one-geometry-out settings, so fitted improvements require an in-sample
qualification.

Pooled costs remain additive and were run through the canonical pipeline for
all 42 matched subtrees. Natural lineage lies on the sampled front in 27/42,
versus 15/42 using embryo-1 travel on identical shared edges; some individual
subtree changes are large. Adoption would reduce current primary coverage
from 299 to 275 edges and 43 to 42 eligible subtrees. The pooled matrix is
saved in `candidate_travel_matrices.npz` within the comparison directory,
with global normalization factors fixed across subtrees.

The comparison supports pooling as a practical candidate for an
ensemble-average primary metric and minimax as a complementary sensitivity
analysis. A primary change would require coordinated regeneration of the
remaining publication analyses and narrative. Accepted outputs retain their
current configuration; these results have not silently changed that baseline.
