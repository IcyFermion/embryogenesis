"""Check pooled metric compatibility with the 42 matched canonical subtrees."""
from pathlib import Path
import hashlib
import json
import sys

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from terminal_pareto import data_loader as dl, lineage_metrics as lm, pareto_engine as pe
from terminal_pareto.subtree_analysis import exact_cousin_stats
from terminal_pareto.tracking_geometry_sensitivity import sweep
from terminal_pareto.fig5_table1_ce_canonical_metrics import compute_front_landmarks
from terminal_pareto.compare_tracking_travel_metrics import OUT, cf


def main():
    data = np.load(cf.CACHE)
    pooled = np.load(OUT / 'candidate_travel_matrices.npz')['normalized_mean']
    lineage = json.loads((ROOT / 'data/cell_lineage.json').read_text())
    index = lm.build_lineage_tree_index(lineage)
    reference = dict(dl.collect_all_subtrees(lineage, set(index), min_cells=1))
    manifest_path = ROOT / 'terminal_pareto/output/ce_tracking_replicate_subtree_manifest.csv'
    manifest = pd.read_csv(manifest_path)
    eligible = manifest[manifest.eligible_common_min12]
    assert len(eligible) == 42
    terms = list(zip(data['children'], data['natural_parents']))
    gp = pe.build_grandparent_map(lineage)
    records, assignments = [], {}
    for item in eligible.itertuples():
        descendant_edges = set(reference[item.subtree])
        selected = np.array([i for i, term in enumerate(terms) if term in descendant_edges])
        assert len(selected) == item.n_common and len(selected) >= 12
        children, parents = data['children'][selected], data['natural_parents'][selected]
        expression = data['expression_matrix'][np.ix_(selected, selected)]
        groups = pe.build_cousin_groups(children, gp)
        for metric, full in [('embryo1_matched', data['embryo1_travel_matrix']), ('pooled', pooled)]:
            travel = full[np.ix_(selected, selected)]
            mt, ms, vt, vs, cov = exact_cousin_stats(travel, expression, groups)
            assert vt > 0 and vs > 0
            front = sweep(travel, expression, np.sqrt(vt), np.sqrt(vs), parents, 300)
            lt, ls = np.trace(travel), np.trace(expression)
            landmarks = compute_front_landmarks((front['t'] - lt) / np.sqrt(vt),
                                                (front['s'] - ls) / np.sqrt(vs),
                                                front['retention'], (mt - lt) / np.sqrt(vt),
                                                (ms - ls) / np.sqrt(vs))
            record = dict(metric=metric, subtree=item.subtree, n=len(selected),
                          major_subtree=item.major_subtree, natural_travel=lt,
                          travel_null_sd=np.sqrt(vt))
            for key in ['d_lp', 'd_np', 'u_lineage_lp', 'max_er', 'endpoint_ok',
                        'exactly_on_front', 'natural_on_grid', 'n_front_points']:
                record[key] = landmarks[key]
            records.append(record)
            assignments[f'{item.subtree}_{metric}'] = front['assignments']
        assignments[f'{item.subtree}_indices'] = selected
    frame = pd.DataFrame(records)
    frame.to_csv(OUT / 'matched_subtree_metrics.csv', index=False)
    np.savez_compressed(OUT / 'matched_subtree_assignments.npz', **assignments)
    current = pd.read_csv(ROOT / 'terminal_pareto/output/ce_subtree_canonical_metrics.csv')
    assert len(current) == 43
    comparison = frame.pivot(index='subtree', columns='metric', values=['d_lp', 'u_lineage_lp', 'max_er'])
    summary = dict(n_current_primary_edges=int(current[current.subtree == 'P0'].n.iloc[0]),
                   n_shared_edges=len(terms), n_current_subtrees=len(current), n_shared_subtrees=len(eligible),
                   d_lp_median_absolute_change=float(np.median(np.abs(comparison.d_lp.pooled - comparison.d_lp.embryo1_matched))),
                   d_lp_max_absolute_change=float(np.max(np.abs(comparison.d_lp.pooled - comparison.d_lp.embryo1_matched))),
                   u_median_absolute_change=float(np.median(np.abs(comparison.u_lineage_lp.pooled - comparison.u_lineage_lp.embryo1_matched))),
                   retention_median_absolute_change=float(np.median(np.abs(comparison.max_er.pooled - comparison.max_er.embryo1_matched))),
                   dropped_subtrees=sorted(set(current.subtree) - set(eligible.subtree)))
    (OUT / 'subtree_audit_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    inputs = [Path(__file__), cf.CACHE, OUT / 'candidate_travel_matrices.npz', manifest_path,
              ROOT / 'terminal_pareto/fig5_table1_ce_canonical_metrics.py',
              ROOT / 'terminal_pareto/tracking_geometry_sensitivity.py',
              ROOT / 'terminal_pareto/subtree_analysis.py', ROOT / 'data/cell_lineage.json']
    (OUT / 'subtree_audit_provenance.json').write_text(json.dumps(
        {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
