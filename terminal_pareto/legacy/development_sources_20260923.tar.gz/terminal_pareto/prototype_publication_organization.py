"""Cache-only publication layout prototypes; never promotes accepted figures.

Run from the repository root in the dev environment. Outputs are isolated in
output/publication_organization_prototype. No optimizations are performed.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from terminal_pareto.analysis_context import build_analysis_context, validate_existing_context_manifest
from terminal_pareto.global_analysis import load_global_analysis
from terminal_pareto.front_coordinates import null_sd_coordinates
from terminal_pareto.fig2_fig3_ce_terminal_pareto import _display_data, plot_main
from terminal_pareto.fig5_figs1_ce_canonical_summary import plot_definition_dlp
from terminal_pareto import plot_style as ps

BASE = ROOT / "terminal_pareto/output"
OUT = BASE / "publication_organization_prototype"
TRACK = BASE / "tracking_geometry_sensitivity"
COMP = BASE / "tracking_metric_comparison"
REPS = ["embryo1", "embryo2", "embryo3"]
COLORS = ["#4477AA", "#CC6677", "#228833"]
POOL, ROBUST = "#202020", "#873E82"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(fig, name):
    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"{name}.{ext}", dpi=220, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def load_data(context):
    """Reconstruct plotted costs against the current source-derived matrices."""
    cache = np.load(TRACK / "assignments_and_costs.npz", allow_pickle=False)
    np.testing.assert_array_equal(cache["children"], context.terminal_nodes)
    np.testing.assert_array_equal(cache["natural_parents"], context.terminal_parents)
    # The older cache used a different vectorized cosine evaluation order.
    np.testing.assert_allclose(cache["expression_matrix"], context.expression_matrix, atol=1e-12, rtol=0)
    rows = np.arange(len(context.terminal_nodes))
    ns = np.trace(context.expression_matrix)
    transfer = np.empty((3, 3))
    projected = []
    for i, rep in enumerate(REPS):
        matrix = cache[rep + "_travel_matrix"]
        np.testing.assert_allclose(matrix, context.component_travel_matrices[rep], atol=1e-12, rtol=0)
        assignments = cache[rep + "_assignments"]  # child index per parent slot
        np.testing.assert_array_equal(np.sort(assignments, axis=1), np.broadcast_to(rows, assignments.shape))
        state = context.expression_matrix[rows, assignments].sum(axis=1)
        mean = context.travel_matrix[rows, assignments].sum(axis=1)
        projected.extend(dict(source=rep, step=k, travel_change_pct=100*(t-1),
                              state_change_pct=100*(s/ns-1))
                         for k, (t, s) in enumerate(zip(mean, state)))
        endpoint = assignments[-1]
        for j, target in enumerate(REPS):
            target_matrix = context.component_travel_matrices[target]
            rr, cc = linear_sum_assignment(target_matrix)
            optimum = target_matrix[rr, cc].sum()
            transfer[i, j] = 100*(target_matrix[rows, endpoint].sum()/optimum-1)
    transfer[np.abs(transfer) < 1e-10] = 0.0
    # Certified budget solutions store unique biological-parent indices per child.
    names, first, capacity = np.unique(cache["natural_parents"], return_index=True, return_counts=True)
    records = json.loads((COMP / "pooled_solver_records.json").read_text())
    dense = []
    for record in records:
        a = np.asarray(record["assignment"], dtype=int)
        np.testing.assert_array_equal(np.bincount(a, minlength=len(names)), capacity)
        slot = first[a]
        state = context.expression_matrix[slot, rows].sum()
        mean = context.travel_matrix[slot, rows].sum()
        assert record["status"] == "optimal" and abs(record["absolute_gap"]) < 1e-7
        assert state <= record["budget"] + 1e-5
        np.testing.assert_allclose([mean, state], [record["mean_ratio"], record["expression"]], atol=1e-9, rtol=0)
        np.testing.assert_allclose(mean, record["lower_bound"], atol=1e-7, rtol=0)
        dense.append(dict(source="pooled", point_id=record["point_id"],
                          travel_change_pct=100*(mean-1), state_change_pct=100*(state/ns-1)))
    # Independent recomputation of the displayed no-state-increase examples.
    headline = pd.read_csv(COMP / "headline_comparison.csv")
    headline = headline.loc[np.isclose(headline.required_state_reduction_pct, 0)].iloc[0]
    reductions = {}
    paths = {"pooled": COMP / "pooled_solver_records.json",
             "minimax": BASE / "common_tracking_assignment/dense_front/solver_records.json"}
    for method, path in paths.items():
        record = next(r for r in json.loads(path.read_text()) if r["point_id"] == headline.point_id)
        a = np.asarray(record["assignment"], dtype=int)
        np.testing.assert_array_equal(np.bincount(a, minlength=len(names)), capacity)
        slot = first[a]
        state = context.expression_matrix[slot, rows].sum()
        assert state <= ns + 1e-5 and record["status"] == "optimal"
        assert abs(record["absolute_gap"]) < 1e-7
        ratios = np.array([context.component_travel_matrices[r][slot, rows].sum()
                           / context.component_natural_totals[r] for r in REPS])
        objective = ratios.mean() if method == "pooled" else ratios.max()
        np.testing.assert_allclose(objective, record["lower_bound"], atol=1e-7, rtol=0)
        reductions[method] = 100*(1-np.r_[ratios.mean(), ratios])
        np.testing.assert_allclose(reductions[method],
            [headline[method+"_mean_reduction_pct"]] +
            [headline[method+"_"+r+"_reduction_pct"] for r in REPS], atol=1e-8)
    return transfer, pd.DataFrame(projected), pd.DataFrame(dense), reductions


def style(ax, letter, title):
    ax.set_title(title, loc="left", fontsize=10, pad=12, fontweight="semibold")
    ax.text(-.19, 1.06, letter, transform=ax.transAxes, fontsize=12, fontweight="bold")
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(labelsize=8)


def render_s3(transfer, projected, dense, reductions):
    fig = plt.figure(figsize=(8.0, 6.5))
    gs = fig.add_gridspec(2, 2, width_ratios=[1, 1.3], height_ratios=[1.15, 1],
                          left=.12, right=.96, bottom=.14, top=.89, hspace=.70, wspace=.48)
    ax = fig.add_subplot(gs[0, 0])
    ax.imshow(transfer, cmap="Blues", vmin=0, vmax=25, aspect="auto")
    for i in range(3):
        for j in range(3):
            ax.text(j, i, f"{transfer[i,j]:.1f}%", ha="center", va="center", fontsize=10,
                    color="white" if transfer[i,j] > 16 else "#222222")
    ax.set(xticks=range(3), yticks=range(3), xticklabels=["1", "2", "3"],
           yticklabels=["1", "2", "3"], xlabel="Evaluated in embryo", ylabel="Optimized in embryo")
    style(ax, "A", "Travel optima do not transfer")
    ax.text(.5, -.28, "Excess travel above target optimum", ha="center", transform=ax.transAxes, fontsize=8)
    ax = fig.add_subplot(gs[0, 1])
    for rep, color in zip(REPS, COLORS):
        frame = projected[projected.source == rep].sort_values("state_change_pct")
        ax.plot(frame.travel_change_pct, frame.state_change_pct, color=color, lw=1.2,
                marker=".", ms=3, label=f"Embryo {rep[-1]} fit")
    frame = dense.sort_values("state_change_pct")
    ax.plot(frame.travel_change_pct, frame.state_change_pct, color=POOL, lw=1.8,
            marker=".", ms=2, label="Pooled fit")
    ax.axvline(0, color="#999999", lw=.7, ls=":")
    ax.axhline(0, color="#999999", lw=.7, ls=":")
    ax.scatter([0], [0], marker="X", color="#222222", s=42, zorder=5, label="Natural lineage")
    ax.set(xlim=(-4, 3), ylim=(-3, 1.1), xlabel="Pooled travel change (%)",
           ylabel="Cell-state change (%)")
    ax.grid(alpha=.15)
    ax.legend(fontsize=7, frameon=True, facecolor="white", edgecolor="none",
              framealpha=.97, loc="upper right", handlelength=1.5)
    style(ax, "B", "One shared pooled cost space")
    ax.text(.5, -.28, "Near natural lineage; lower costs to lower left", ha="center", transform=ax.transAxes, fontsize=8)
    ax = fig.add_subplot(gs[1, :])
    for method, color, offset, marker, label in [
        ("pooled", POOL, -.10, "o", "Pooled optimum"),
        ("minimax", ROBUST, .10, "s", "Worst-embryo optimum")]:
        vals = reductions[method]
        y = np.arange(4) + offset
        ax.scatter(vals, y, color=color, marker=marker, s=34, label=label, zorder=4)
        for xx, yy in zip(vals, y):
            ax.annotate(f"{xx:+.2f}%", (xx, yy), xytext=(6, 0), textcoords="offset points",
                        va="center", fontsize=8, color=color)
    ax.axvline(0, color="#999999", lw=.8, ls=":")
    ax.axhspan(-.4, .4, color="#EAEAEA", zorder=0)
    ax.set(yticks=range(4), yticklabels=["Pooled mean", "Embryo 1", "Embryo 2", "Embryo 3"],
           ylim=(3.5, -.5), xlim=(-1, 7.2), xlabel="Travel reduction from natural lineage (%)")
    ax.legend(fontsize=8, frameon=False, loc="lower right")
    style(ax, "C", "A common assignment improves the mean, with a trade-off")
    ax.texts[-1].set_position((-.07, 1.06))
    fig.suptitle("Tracking sensitivity and the choice of pooled travel", x=.52, y=.98,
                 fontsize=13, fontweight="semibold")
    fig.text(.52, .937, "275 shared edges  |  three measured geometries  |  fixed protein cell-state costs",
             fontsize=9, ha="center", color="#555555")
    fig.text(.12, .050, "C: one assignment per method, shared across embryos; cell-state cost cannot exceed natural lineage.", fontsize=8)
    fig.text(.12, .025, "Pooling targets the measured-embryo mean. It does not guarantee improvement in every embryo or a new embryo.", fontsize=8)
    save(fig, "figS3_tracking_pooled_prototype")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    ps.configure()
    context = build_analysis_context("pooled_tracking_v1", run_id="migration_candidate_20260920")
    validate_existing_context_manifest(context)
    result = load_global_analysis(context)
    # Export a separate amendment; no access to or modification of co-author Figure 1.
    fig, ax = plt.subplots(figsize=(7.0, 3.6))
    fig.subplots_adjust(left=.16, right=.84, bottom=.18, top=.84)
    plot_definition_dlp(ax, panel_letter="")
    for text in ax.texts:
        text.set_fontsize(text.get_fontsize()*1.35)
    ax.set_title("Endpoint coordinates and canonical metrics", fontsize=13, loc="left", pad=12)
    with plt.rc_context({"svg.fonttype": "none"}):
        fig.savefig(OUT/"fig1_endpoint_normalization_amendment.svg", bbox_inches="tight")
    save(fig, "fig1_endpoint_normalization_amendment")
    keys = {1:"first_cousin", 2:"second_cousin", 3:"third_cousin", "full":"full_random"}
    nulls = {k:null_sd_coordinates(*result.null_raw[v], natural_costs=result.natural_costs,
                                   null_stds=result.null_stds) for k,v in keys.items()}
    display = _display_data(result.twr, nulls, mode="endpoint", result=result, context=context)
    fig = plot_main(result.twr, nulls, display=display, out_dir=OUT, panel_letter=None)
    plt.close(fig)
    transfer, projected, dense, reductions = load_data(context)
    render_s3(transfer, projected, dense, reductions)
    pd.DataFrame(transfer, index=REPS, columns=REPS).to_csv(OUT/"travel_endpoint_transfer_pct.csv")
    pd.concat([projected, dense], ignore_index=True).to_csv(OUT/"pooled_space_assignments.csv", index=False)
    pd.DataFrame(reductions, index=["mean"]+REPS).to_csv(OUT/"common_assignment_reductions.csv")
    inputs = [TRACK/"assignments_and_costs.npz", COMP/"pooled_solver_records.json",
              COMP/"headline_comparison.csv", BASE/"common_tracking_assignment/dense_front/solver_records.json",
              context.run_paths.analysis/"global_terminal_analysis.npz",
              context.run_paths.analysis/"global_terminal_analysis.json"]
    sources = [Path(__file__), ROOT/"terminal_pareto/fig2_fig3_ce_terminal_pareto.py",
               ROOT/"terminal_pareto/fig5_figs1_ce_canonical_summary.py"]
    (OUT/"provenance.json").write_text(json.dumps({
        "status":"layout prototype, not promoted", "context_cache_key":context.cache_key,
        "input_sha256":{str(p.relative_to(ROOT)):digest(p) for p in inputs+sources},
        "checks":["source-derived matrix/cohort equality", "native slot permutations",
                  "budget solution parent capacities and feasibility", "recorded costs and optimal bounds",
                  "Figure 2 validated production global cache"],
        "scope":"Panel A: travel endpoints only; B: sampled assignments in pooled space near nature; C: no state-cost increase",
    }, indent=2)+"\n")
    subprocess.run(["pdfunite", str(OUT/"fig1_endpoint_normalization_amendment.pdf"),
                    str(OUT/"fig2_ce_terminal_pareto_front.pdf"),
                    str(OUT/"figS3_tracking_pooled_prototype.pdf"),
                    str(OUT/"publication_organization_review.pdf")], check=True)
    print(f"Wrote reviewed-layout prototypes to {OUT}")


if __name__ == "__main__":
    main()
