"""Two-panel, linked-example alternative to the first tracking S3 prototype.

Uses validated saved assignments; outputs a separate review-only v2.
"""
from pathlib import Path
import hashlib
import json
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from terminal_pareto import prototype_publication_organization as source
from terminal_pareto.analysis_context import build_analysis_context, validate_existing_context_manifest

OUT = source.OUT / "approachable_v2"
POOLED = "#167D92"
SINGLE = "#93999E"


def render(projected, dense, reductions, example):
    plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":9,
                         "axes.labelsize":9, "pdf.fonttype":42,
                         "svg.fonttype":"none"})
    fig = plt.figure(figsize=(8.1, 5.7))
    ax = fig.add_axes([.095, .27, .43, .46])
    bx = fig.add_axes([.685, .27, .275, .46])
    fig.text(.095, .965, "Why combine tracking data from three embryos?",
             fontsize=14, fontweight="bold", va="top")
    fig.text(.095, .912, "Same 275 terminal cells and protein costs; only the travel metric changes.",
             fontsize=9.2, color="#444444")
    fig.text(.095, .857,
             "Pooled travel = the average across embryos, after scaling each embryo to its natural travel cost.",
             fontsize=8.6, color=POOLED,
             bbox=dict(boxstyle="round,pad=.5", facecolor="#EDF5F6", edgecolor="none"))
    fig.text(.045, .79, "A", fontsize=12, fontweight="bold")
    fig.text(.095, .79, "Choose parents using one embryo or all three", fontsize=9.6, fontweight="bold")
    fig.text(.095, .754, "Evaluate every assignment using the same pooled travel metric", fontsize=8, color="#555555")
    fig.text(.63, .79, "B", fontsize=12, fontweight="bold")
    fig.text(.685, .79, "Follow the starred assignment", fontsize=9.6, fontweight="bold")
    fig.text(.685, .754, "Keep its parent choices fixed in every embryo", fontsize=8, color="#555555")

    for rep, ls in zip(source.REPS, ["-", "--", ":"]):
        frame = projected[projected.source == rep].sort_values("state_change_pct")
        ax.plot(100+frame.travel_change_pct, 100+frame.state_change_pct,
                color=SINGLE, ls=ls, lw=1.15, marker=".", ms=2)
    frame = dense.sort_values("state_change_pct")
    ax.plot(100+frame.travel_change_pct, 100+frame.state_change_pct,
            color=POOLED, lw=2, marker=".", ms=2)
    ax.fill_between([96, 100], 97, 100, color="#EDF5F6", zorder=-2)
    ax.axvline(100, color="#555555", lw=.8, ls=(0, (2, 3)))
    ax.axhline(100, color="#555555", lw=.8, ls=(0, (2, 3)))
    ax.scatter([100], [100], marker="X", s=50, color="#222222", zorder=5)
    ax.annotate("Natural lineage", (100,100), xytext=(4, 9), textcoords="offset points",
                fontsize=8, ha="left", bbox=dict(facecolor="white", edgecolor="none", pad=.8))
    star = (100+example.travel_change_pct, 100+example.state_change_pct)
    ax.scatter(*star, marker="*", s=140, color=POOLED, edgecolor="white", lw=.7, zorder=6)
    ax.annotate("Same assignment\nin panel B", star, xytext=(96.95,100.63), fontsize=8,
                color=POOLED, arrowprops=dict(arrowstyle="-", color=POOLED, lw=.7))
    ax.text(96.18,97.15,"Both costs below natural", fontsize=8, color="#567A80")
    ax.set(xlim=(96,103.2), ylim=(97,101.15), xticks=[96,98,100,102], yticks=[97,98,99,100,101],
           xlabel="Average travel cost\n(% of natural lineage)", ylabel="Cell-state cost\n(% of natural lineage)")
    ax.legend(handles=[Line2D([],[],color=SINGLE,lw=1.3,label="One embryo at a time (three curves)"),
                       Line2D([],[],color=POOLED,lw=2,label="All three embryos together (pooled)")],
              loc="upper left", bbox_to_anchor=(0,-.29), borderaxespad=0, fontsize=8, frameon=False)

    # Same pooled assignment as the star, evaluated without reoptimization.
    values = 100-reductions["pooled"][[1,2,3,0]]
    np.testing.assert_allclose(values[-1], star[0], atol=1e-9)
    assert star[1] <= 100+1e-8
    bx.axvline(100, color="#555555", lw=.8, ls=(0, (2, 3)))
    bx.axhspan(2.65,3.35,color="#EDF5F6",zorder=-2)
    bx.text(99.85, -.58, "Natural = 100%", fontsize=8, ha="right", color="#555555")
    for y, val in enumerate(values):
        color = "#AD642E" if val > 100 else POOLED
        bx.plot([val,100],[y,y],color=color,lw=1.2,alpha=.65)
        bx.scatter([val],[y],marker="*" if y==3 else "o",s=125 if y==3 else 38,
                   color=color,edgecolor="white",lw=.6,zorder=5)
        bx.annotate(f"{val:.2f}%",(val,y),xytext=(0,10),textcoords="offset points",
                    ha="center",fontsize=8,color=color,
                    bbox=dict(facecolor="white",edgecolor="none",pad=.5))
    bx.set(xlim=(93.3,101.7),ylim=(3.7,-.9),xticks=[94,96,98,100],
           yticks=range(4),yticklabels=["Embryo 1","Embryo 2","Embryo 3","Average"],
           xlabel="Travel cost\n(% of natural lineage)")
    bx.text(.5,-.31,"Average: 2.98% less travel\nEmbryo 3: 0.13% more travel",
            transform=bx.transAxes,ha="center",va="top",fontsize=9,color="#333333",linespacing=1.5)
    for a in (ax,bx):
        a.spines[["top","right"]].set_visible(False)
        a.tick_params(labelsize=8)
    fig.text(.095,.045,"100% = natural lineage in both panels. Lower cost is better. Panel A shows the region near natural lineage.",fontsize=8)
    fig.text(.095,.012,"The star minimizes pooled travel without increasing cell-state cost. It is one shared assignment, not a separate fit to each embryo.",fontsize=8)
    for ext in ("pdf","png","svg"):
        fig.savefig(OUT/f"figS3_tracking_readable.{ext}",dpi=220,bbox_inches="tight",facecolor="white")
    plt.close(fig)
    return values


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    context=build_analysis_context("pooled_tracking_v1",run_id="migration_candidate_20260920")
    validate_existing_context_manifest(context)
    _, projected, dense, reductions=source.load_data(context)
    headline=pd.read_csv(source.COMP/"headline_comparison.csv")
    record=headline.loc[np.isclose(headline.required_state_reduction_pct,0)].iloc[0]
    example=dense.loc[dense.point_id==record.point_id].iloc[0]
    values=render(projected,dense,reductions,example)
    pd.concat([projected,dense],ignore_index=True).to_csv(OUT/"front_coordinates.csv",index=False)
    pd.DataFrame({"geometry":["embryo1","embryo2","embryo3","mean"],
                  "travel_percent_natural":values}).to_csv(OUT/"shared_assignment.csv",index=False)
    inputs=[source.TRACK/"assignments_and_costs.npz",source.COMP/"pooled_solver_records.json",
            source.COMP/"headline_comparison.csv",Path(source.__file__),Path(__file__)]
    (OUT/"provenance.json").write_text(json.dumps({
        "status":"review-only alternative; previous prototype preserved",
        "context_cache_key":context.cache_key,"shared_assignment_point_id":record.point_id,
        "shared_assignment_state_percent_natural":100+example.state_change_pct,
        "input_sha256":{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},
        "checks":"source-derived matrices, saved assignment costs/capacities/budgets/bounds; mean equals star travel coordinate",
        "caveat":"Gray curves are sampled single-embryo assignments reevaluated in pooled space; not optima for the displayed metric."
    },indent=2)+"\n")
    print(OUT/"figS3_tracking_readable.pdf")


if __name__=="__main__":
    main()
