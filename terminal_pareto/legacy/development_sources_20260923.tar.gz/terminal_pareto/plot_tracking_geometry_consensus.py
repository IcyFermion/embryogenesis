"""Add validated common assignments to the original tracking review figure.

Render cached results only; do not rerun optimization or change accepted S3.
Use --dense-front for an endpoint-to-endpoint budget sweep; by default show
the three original budget solutions. Neither enumerates the full discrete
Pareto set. Run from the repository root in the dev environment.
"""
import argparse
from pathlib import Path
import hashlib
import itertools
import json
import shutil
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from terminal_pareto.figS3_ce_tracking_variance_amendment import (
    COMMON, TRACK, PAIR_COLORS, load_and_validate,
)

COLORS = {'embryo1': '#4477AA', 'embryo2': '#EE6677', 'embryo3': '#228833'}
PURPLE = '#793879'
MARKERS = ['*', 's', '^']
SIZES = [100, 42, 52]


def load_dense_front(folder):
    provenance = json.loads((folder / 'provenance.json').read_text())
    assert provenance['cache_sha256'] == hashlib.sha256((TRACK / 'assignments_and_costs.npz').read_bytes()).hexdigest()
    assert provenance['source_sha256'] == hashlib.sha256((ROOT / 'terminal_pareto/common_tracking_front.py').read_bytes()).hexdigest()
    data = np.load(TRACK / 'assignments_and_costs.npz')
    saved = np.load(folder / 'front_assignments.npz')
    records = json.loads((folder / 'solver_records.json').read_text())
    assert len(records) == len(saved['assignments'])
    assert np.array_equal(saved['children'], data['children'])
    names, first, _, capacity = np.unique(data['natural_parents'], return_index=True,
                                        return_inverse=True, return_counts=True)
    assert np.array_equal(names, saved['parent_names'])
    children = np.arange(len(data['children']))
    seen = set()
    rows = []
    for record, assignment, point_id in zip(records, saved['assignments'], saved['point_ids']):
        assert record['point_id'] == point_id
        assert np.array_equal(record['assignment'], assignment)
        assert np.array_equal(np.bincount(assignment, minlength=len(capacity)), capacity)
        state = data['expression_matrix'][first[assignment], children].sum()
        np.testing.assert_allclose(state, record['expression'], rtol=0, atol=1e-8)
        assert state <= record['budget'] + 1e-5
        ratios = []
        for r in COLORS:
            cost = data[r + '_travel_matrix'][first[assignment], children].sum()
            np.testing.assert_allclose(cost, record[r + '_travel'], rtol=0, atol=1e-8)
            np.testing.assert_allclose(np.trace(data[r + '_travel_matrix']), record[r + '_natural_travel'])
            ratios.append(cost / record[r + '_natural_travel'])
        np.testing.assert_allclose(max(ratios), record['worst_travel_ratio'], rtol=0, atol=1e-10)
        if record.get('lower_bound') is not None:
            assert record['lower_bound'] <= max(ratios) + 1e-7
        if record['status'] == 'optimal':
            assert record['absolute_gap'] < 1e-7
        key = tuple(assignment)
        if key not in seen:
            seen.add(key)
            rows.append({k: v for k, v in record.items() if k != 'assignment'})
    dense = pd.DataFrame(rows)
    # Remove points dominated in the JOINT (worst travel ratio, state) space.
    # Do not filter projections independently: all panels must show the same assignments.
    keep = []
    for i, point in dense.iterrows():
        dominates = ((dense.expression <= point.expression + 1e-9) &
                     (dense.worst_travel_ratio <= point.worst_travel_ratio + 1e-10) &
                     ((dense.expression < point.expression - 1e-9) |
                      (dense.worst_travel_ratio < point.worst_travel_ratio - 1e-10)))
        if not dominates.any():
            keep.append(i)
    dense = dense.loc[keep].sort_values('expression', ascending=False).reset_index(drop=True)
    dense.to_csv(folder / 'plotted_nondominated_front.csv', index=False)
    return dense, records


def render_joint_objectives(dense, records):
    fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.9))
    fig.subplots_adjust(left=.085, right=.98, bottom=.24, top=.82, wspace=.32)
    fig.suptitle('Consensus trade-off across three tracking geometries', fontsize=14, y=.97)
    fig.text(.53, .9, f'{len(dense)} distinct sampled assignments | '
             f'{sum(r["status"] == "optimal" for r in records)}/{len(records)} budget solves certified',
             ha='center', fontsize=10)
    x = 100 * (dense.expression / dense.expression_natural - 1)
    y = 100 * (dense.worst_travel_ratio - 1)
    exact = dense.status == 'optimal'
    for ax in axes:
        ax.plot(x, y, color=PURPLE, lw=1.2, alpha=.75)
        ax.scatter(x[exact], y[exact], color=PURPLE, s=17, zorder=3, label='Certified budget optimum')
        if (~exact).any():
            ax.scatter(x[~exact], y[~exact], facecolor='white', edgecolor='#CC7722',
                       s=30, zorder=4, label='Feasible; time-limited')
        ax.scatter([0], [0], color='#222222', marker='+', s=75, zorder=4, label='Natural lineage')
        ax.axhline(0, color='#999999', lw=.7, ls=':')
        ax.axvline(0, color='#999999', lw=.7, ls=':')
        ax.set(xlabel='Cell-state cost change from natural (%)',
               ylabel='Worst travel cost change across embryos (%)')
        ax.spines[['top', 'right']].set_visible(False)
    axes[0].set_title('A  Full endpoint-to-endpoint range', loc='left', fontsize=10)
    axes[0].legend(frameon=False, fontsize=8, loc='upper right')
    axes[0].annotate('Minimum cell-state cost', (x.iloc[-1], y.iloc[-1]),
                     xytext=(12, -4), textcoords='offset points', fontsize=8, color=PURPLE)
    axes[0].annotate('Minimum worst travel', (x.iloc[0], y.iloc[0]),
                     xytext=(-108, 20), textcoords='offset points', fontsize=8, color=PURPLE,
                     arrowprops=dict(arrowstyle='-', color=PURPLE, lw=.7))
    axes[1].set_title('B  Near natural lineage', loc='left', fontsize=10)
    axes[1].set(xlim=(-3.5, 1.5), ylim=(-4, 1.5))
    axes[1].add_patch(Rectangle((-3.5, -4), 3.5, 4, facecolor='#E9F2E9', ec='none', zorder=0))
    axes[1].text(.04, .06, 'Both costs lower in every embryo', transform=axes[1].transAxes,
                 fontsize=8, color='#427343')
    fig.text(.085, .11, 'Worst travel change is the maximum of the three embryo-specific percentage changes.', fontsize=9)
    fig.text(.085, .065, 'Points are feasible common assignments; connecting lines are guides. '
             'Dense budget sampling does not enumerate every discrete Pareto solution.', fontsize=8)
    for extension in ['pdf', 'png']:
        fig.savefig(TRACK / f'consensus_objective_front.{extension}', dpi=180)
    plt.close(fig)


def render(dense_folder=None):
    transfer, neighborhoods, common, _ = load_and_validate()
    scales = pd.read_csv(TRACK / 'front_summary.csv').set_index('replicate')
    dense, records = load_dense_front(dense_folder) if dense_folder else (None, [])
    coordinates = []
    for r in COLORS:
        for row in common.itertuples():
            travel = getattr(row, r + '_travel')
            natural = getattr(row, r + '_natural_travel')
            np.testing.assert_allclose(natural, scales.loc[r, 'travel_natural'])
            x = (travel - natural) / scales.loc[r, 'travel_null_sd']
            y = (row.expression - row.expression_natural) / scales.loc[r, 'expression_null_sd']
            assert x < 0 and y < 0, 'Every common assignment must improve both costs'
            assert row.expression <= row.expression_budget + 1e-8
            coordinates.append(dict(
                replicate=r, required_state_reduction_pct=row.expression_reduction_required_pct,
                travel_change_sigma=x, state_change_sigma=y,
                travel_reduction_pct=100 * (1 - travel / natural),
                state_reduction_pct=100 * (1 - row.expression / row.expression_natural),
            ))
    coordinates = pd.DataFrame(coordinates)

    # Preserve the pre-overlay artifact once, including on subsequent renders.
    backup = TRACK / ('before_dense_consensus' if dense_folder else 'before_consensus_overlay')
    backup.mkdir(exist_ok=True)
    for suffix in ['pdf', 'png']:
        source = TRACK / f'tracking_geometry_review.{suffix}'
        if source.exists() and not (backup / source.name).exists():
            shutil.copy2(source, backup / source.name)

    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9,
                         'axes.labelsize': 9, 'axes.titlesize': 10,
                         'axes.linewidth': .7, 'pdf.fonttype': 42})
    fig, axes = plt.subplots(3, 3, figsize=(12.6, 11.4))
    fig.subplots_adjust(left=.075, right=.98, top=.86, bottom=.14,
                        hspace=.51, wspace=.31)
    fig.suptitle('Tracking sensitivity and cross-embryo consensus assignments',
                 fontsize=16, x=.52, y=.983)
    fig.text(.52, .95, 'C. elegans | 275 matched terminal edges | 3 tracking geometries | fixed protein costs',
             ha='center', color='#555555', fontsize=10)
    source_handles = [Line2D([], [], color=c, lw=1.8, label=f'Optimized in embryo {r[-1]}')
                      for r, c in COLORS.items()]
    source_handles += [Line2D([], [], color='#222222', marker='+', ms=9, ls='',
                              label='Natural lineage'),
                       Line2D([], [], color=PURPLE, lw=1.5, ls='--',
                              label='Sampled consensus front' if dense_folder else 'Sampled consensus trade-off')]
    fig.legend(handles=source_handles, loc='upper center', bbox_to_anchor=(.52, .932),
               ncol=5, frameon=False, fontsize=8.4, handlelength=2, columnspacing=1.5)
    common_handles = [Line2D([], [], color=PURPLE, marker=m, ls='', ms=9 if j == 0 else 6,
                             label=f'{b:g}% required cell-state reduction')
                      for j, (m, b) in enumerate(zip(MARKERS, common.expression_reduction_required_pct))]
    fig.legend(handles=common_handles, loc='upper center', bbox_to_anchor=(.52, .904),
               ncol=3, frameon=False, fontsize=8.4, columnspacing=2)

    for col, target in enumerate(COLORS):
        scale = scales.loc[target]
        points = coordinates[coordinates.replicate == target]
        zoom_bottom = -4.2 if dense is not None else -2
        zoom_top = .65 if dense is not None else .55
        for row_index in [0, 1]:
            ax = axes[row_index, col]
            for source, color in COLORS.items():
                data = transfer[(transfer.source == source) & (transfer.target == target)]
                ax.plot((data.travel - scale.travel_natural) / scale.travel_null_sd,
                        (data.expression - common.expression_natural.iloc[0]) / scale.expression_null_sd,
                        color=color, lw=1.8 if source == target else 1,
                        alpha=1 if source == target else .65)
            if dense is not None:
                dx = (dense[target + '_travel'] - scale.travel_natural) / scale.travel_null_sd
                dy = (dense.expression - common.expression_natural.iloc[0]) / scale.expression_null_sd
                ax.plot(dx, dy, color=PURPLE, ls='--', lw=1.3, zorder=5)
                exact = dense.status == 'optimal'
                if row_index == 1:
                    ax.scatter(dx[exact], dy[exact], color=PURPLE, s=7, zorder=5)
                if (~exact).any():
                    ax.scatter(dx[~exact], dy[~exact], facecolor='white', edgecolor='#CC7722',
                               s=15, zorder=5)
            else:
                ax.plot(points.travel_change_sigma, points.state_change_sigma,
                        color=PURPLE, ls='--', lw=1.2, zorder=5)
            for j, point in enumerate(points.itertuples()):
                ax.scatter(point.travel_change_sigma, point.state_change_sigma,
                           color=PURPLE, marker=MARKERS[j], s=SIZES[j],
                           edgecolors='white', linewidths=.5, zorder=6)
            ax.scatter([0], [0], marker='+', s=95, color='#222222', linewidths=1.7, zorder=7)
            ax.set_xlabel('Travel change (target null SD)')
            ax.set_ylabel('Cell-state change (null SD)')
        axes[0, col].set_title(f'{chr(65 + col)}  Evaluated in embryo {target[-1]}', loc='left', pad=9)
        axes[0, col].add_patch(Rectangle((-3.15, zoom_bottom), 3.95, zoom_top - zoom_bottom,
                                         fill=False, ec='#777777', lw=.8, ls=':'))
        zoom = axes[1, col]
        zoom.add_patch(Rectangle((-3.15, zoom_bottom), 3.15, -zoom_bottom, fc='#E9F2E9', ec='none', zorder=0))
        zoom.axhline(0, color='#999999', ls=':', lw=.8)
        zoom.axvline(0, color='#999999', ls=':', lw=.8)
        zoom.set(xlim=(-3.15, .8), ylim=(zoom_bottom, zoom_top), xticks=[-3, -2, -1, 0],
                 yticks=[-4, -3, -2, -1, 0] if dense is not None else [-2, -1, 0])
        zoom.set_title(f'{chr(68 + col)}  Near natural lineage: embryo {target[-1]}', loc='left', pad=9)
        zoom.annotate('Natural', (0, 0), xytext=(6, 9), textcoords='offset points', fontsize=8)
        for point in points.itertuples():
            zoom.annotate(f'{point.travel_reduction_pct:.2f}%',
                          (point.travel_change_sigma, point.state_change_sigma),
                          xytext=(10, -10), textcoords='offset points', color=PURPLE, fontsize=8,
                          bbox=dict(facecolor='white', edgecolor='none', alpha=.8, pad=.5))
        zoom.text(.035, .045, 'Purple labels: travel reduction', transform=zoom.transAxes,
                  fontsize=7.5, color=PURPLE)

    agreement, regret, neighborhood = axes[2]
    for (source, target), color in PAIR_COLORS.items():
        data = transfer[(transfer.source == source) & (transfer.target == target)]
        agreement.plot(data.alpha, data.parent_agreement, color=color, lw=1.3,
                       label=f'{source[-1]} vs {target[-1]}')
    agreement.set(title='G  Agreement in assigned parents', xlabel='Travel weight',
                  ylabel='Biological parent agreement', ylim=(0, 1.03))
    agreement.legend(frameon=False, fontsize=8, loc='lower left', ncol=3,
                     handlelength=1.4, columnspacing=1)
    for source, target in itertools.permutations(COLORS, 2):
        data = transfer[(transfer.source == source) & (transfer.target == target)]
        regret.plot(data.alpha, data.weighted_regret_pct_optimum,
                    color=PAIR_COLORS[tuple(sorted([source, target]))],
                    ls='-' if source < target else '--', lw=1.1,
                    label=f'{source[-1]} to {target[-1]}')
    regret.set(title='H  Cost of transferring assignments', xlabel='Travel weight',
               ylabel='Transfer regret (% target optimum)')
    regret.legend(frameon=False, fontsize=7.5, ncol=2, loc='upper left')
    for (source, target), data in neighborhoods.groupby(['source', 'target']):
        mean = data.groupby('k').overlap.mean()
        neighborhood.plot(mean.index, mean.values, marker='o', ms=4, lw=1.3,
                          color=PAIR_COLORS[tuple(sorted([source, target]))],
                          label=f'{source[-1]} vs {target[-1]}')
    neighborhood.set(title='I  Shared candidate neighborhoods',
                     xlabel='Number of nearest distinct parents',
                     ylabel='Mean neighborhood overlap', ylim=(0, 1), xticks=[3, 5, 10, 20])
    neighborhood.legend(frameon=False, fontsize=8, loc='lower right')
    for ax in axes.flat:
        ax.spines[['top', 'right']].set_visible(False)
        ax.tick_params(labelsize=8)
    for ax in axes[2]:
        ax.set_title(ax.get_title(), loc='left', pad=9)
        ax.set_title('', loc='center')

    fig.text(.075, .090,
             'The same purple point is the same assignment in all three embryos. '
             'Green region: both costs below natural lineage.', fontsize=9)
    fig.text(.075, .066,
             'Consensus objective: minimize the worst travel / natural-travel ratio across embryos, '
             'subject to each cell-state budget.', fontsize=8.3)
    sampling_note = ('Three certified budget solutions sample the joint trade-off; dashed links are visual guides. '
                     'They need not lie on individual fronts.')
    if dense is not None:
        sampling_note = (f'{len(dense)} distinct samples; {sum(r["status"] == "optimal" for r in records)}'
                         f'/{len(records)} solves certified. Dashed links are guides; '
                         'samples need not lie on individual fronts.')
        if any(dense.status != 'optimal'):
            sampling_note += ' Open orange: time-limited.'
    fig.text(.075, .045, sampling_note, fontsize=8.3)
    fig.text(.075, .024,
             'Exploratory, in-sample comparison. Bold colored curves: target-native optima; '
             'thin curves: assignments transferred from another embryo.', fontsize=8.3, color='#555555')
    for suffix in ['pdf', 'png']:
        fig.savefig(TRACK / f'tracking_geometry_review.{suffix}', dpi=180)
    plt.close(fig)
    coordinates.to_csv(TRACK / 'consensus_projected_coordinates.csv', index=False)
    if dense is not None:
        projected = []
        for r in COLORS:
            for row in dense.to_dict('records'):
                projected.append(dict(
                    point_id=row['point_id'], replicate=r, status=row['status'],
                    travel_change_sigma=(row[r + '_travel'] - row[r + '_natural_travel']) / scales.loc[r, 'travel_null_sd'],
                    state_change_sigma=(row['expression'] - row['expression_natural']) / scales.loc[r, 'expression_null_sd']))
        pd.DataFrame(projected).to_csv(TRACK / 'dense_consensus_projected_coordinates.csv', index=False)
        render_joint_objectives(dense, records)
    inputs = [Path(__file__), Path(sys.modules[load_and_validate.__module__].__file__),
              TRACK / 'assignments_and_costs.npz', TRACK / 'transfer.csv',
              TRACK / 'neighborhoods.csv', TRACK / 'front_summary.csv', TRACK / 'provenance.json']
    for folder in [COMMON, COMMON / 'expression_tradeoff']:
        inputs.extend(folder / name for name in
                      ['common_assignments.csv', 'common_assignment_summary.csv', 'provenance.json'])
    if dense_folder:
        inputs.extend(dense_folder / name for name in
                      ['solver_records.json', 'front_assignments.npz', 'provenance.json'])
    provenance = dict(
        description='Cache-only consensus overlay on the original tracking geometry review',
        n_common_assignments=len(common), n_projected_points=len(coordinates),
        complete_consensus_front=False, optimization_rerun=False,
        matplotlib=matplotlib.__version__, numpy=np.__version__, pandas=pd.__version__,
        dense_front_points=0 if dense is None else len(dense),
        dense_projected_points=0 if dense is None else 3 * len(dense),
        dense_budget_solves=len(records),
        sha256={str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs},
    )
    (TRACK / 'consensus_figure_provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    print(coordinates.to_string(index=False))
    print('Saved', TRACK / 'tracking_geometry_review.pdf')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dense-front', type=Path, help='Validated dense-front output directory')
    render(parser.parse_args().dense_front)
