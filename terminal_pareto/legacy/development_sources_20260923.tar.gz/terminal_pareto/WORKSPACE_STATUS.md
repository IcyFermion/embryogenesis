# Terminal publication workspace

Reviewed and tidied 2026-09-23. Paths below are relative to `terminal_pareto/`.

## Current candidate: start here

`output/runs/pooled_tracking_v1/migration_candidate_20260920/publication/endpoint/`
contains the pooled-travel, endpoint-normalized bundle. Open compiled wrappers:

- `fig1_ce_endpoint_normalization_amendment.pdf`: standalone co-author amendment.
- `fig2_ce_terminal_pareto_main.pdf`: single-panel front.
- Figure 3–6 wrappers: structural evidence, subtree map/summaries, cell types.
- `figS1_ce_canonical_summary_cousin_r.pdf`,
  `figS2_ce_cell_type_cost_gain.pdf`, `figS3_ce_tracking_robustness.pdf`.
  S3 is the selected 2-by-2 page with full fronts and near-natural insets.

`publication_build.py` coordinates the build; `publication_wrappers.py`
contains captions. **`prototype_tracking_cross_geometry.py` is an active
publication dependency despite its historical name.** Do not remove or move
it as an obsolete prototype: S3 provenance hashes this source.
`fig1_endpoint_amendment.py` exports the independent Figure 1 component.
The accepted legacy bundle remains in `output/publication/`.

## Supporting analyses and paused work

| Work | Status / reason to retain | Record / output directory |
|---|---|---|
| CE tracking sensitivity | Active S3 assignment source; keep matrices, sweeps, provenance in place | `TRACKING_GEOMETRY_SENSITIVITY.md`; `output/tracking_geometry_sensitivity/` |
| Pooled/minimax comparison | Supporting evidence and migration-validation inputs | `TRACKING_METRIC_COMPARISON.md`; `output/tracking_metric_comparison/` |
| Common tracking assignments | Supporting consensus/shared-improvement evidence | `output/common_tracking_assignment/`; tracking sensitivity record |
| CE protein/RNA and CB AF16 | Paused pilot; retain calibration/provenance boundaries | `PILOT_CROSS_DATASET.md`; `output/pilot_cross_dataset/` |
| AF16 tracking variance | Paused two-replicate audit | `output/af16_tracking_variance/` |
| Organization prototypes v1/v2/v3 | Superseded layouts, archived with compatibility path | `output/publication_organization_prototype/` |
| Earlier S3 amendment | Superseded layout, archived with supporting review/data | `output/tracking_s3_amendment/` |

`prototype_publication_organization.py` and `prototype_tracking_readable.py`
are historical reproduction entrypoints; the latter imports the former.
They remain at their original source paths, outside the publication build.
Do not rerun old renderers merely to clean up: they can overwrite historical
checkpoints. Exploratory solvers remain available for deliberate follow-up;
no pilot was resumed during housekeeping.

## Reversible local archive

`output/archive/housekeeping_20260923/` contains:

- `prototypes/`: complete organization-prototype and earlier S3-amendment
  directories. Original paths are relative compatibility symlinks, so old
  links and reproduction paths still resolve.
- `retired_candidate_panels/`: 14 unreferenced files formerly beside current
  assets: Figure 2A schematic, former Figure 5 A/B/C panels, former S3 A/B
  panels and display manifest, and an obsolete amendment log.
- `manifest.json`: all 63 archived files, original/destination paths, sizes,
  SHA-256 hashes, and 135 protected analysis/accepted/source-file hashes.
- `README.md`: restoration instructions. Nothing was deleted.

The pooled Figure 5 renderer now skips export of the retired Figure 2A
schematic, so full rebuilds do not recreate it. Legacy exports are unchanged.
Generated outputs and the archive are Git-ignored. A source commit does not
back them up; include them in the project's external backup before pruning
outputs or moving machines.

## Review and checks

- All 29 migration checks passed on 2026-09-23, including all 4,816 S3
  projections and unchanged accepted/cache/source hashes.
- The compiled Figure 1 amendment, Figures 2/3/5, and S3 were rendered and
  inspected. S3's separate color and line/marker keys are clear, its insets
  are readable, and its caption fits on one page.
- A temporary Figure 5/S1 render after suppressing the retired export produced
  all five current PNGs byte-for-byte identical to the candidate, without
  emitting Figure 2A.
- Archive hashes and protected-file hashes were verified after moving files.

## Remaining manuscript work

Organization implementation is complete. Next: integrate the Figure 1
amendment with the co-author, revise manuscript text/citations for pooled
travel and the 275-edge/42-subtree cohort, then promote a reviewed bundle.
Standalone article wrappers currently label each caption “Figure 1”;
numbering must come from the integrated manuscript (or be set explicitly
when distributing a numbered review packet). This is an editorial integration
detail, not a change to plotted results.

`PUBLICATION_ORGANIZATION_PROTOTYPE.md` preserves design history and the
completed implementation checklist. Its older v1/v2 captions and prospective
steps are historical, not instructions to restart those layouts.
