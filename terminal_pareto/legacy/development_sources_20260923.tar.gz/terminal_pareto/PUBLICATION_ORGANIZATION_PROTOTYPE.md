# Publication organization prototype and next steps

**Current status, 2026-09-23:** the organization below is implemented in the
isolated candidate and passed the 29-check validation and visual review.
The selected S3 is the one-page 2-by-2 layout with near-natural insets. The
implementation sequence below is a completed historical checklist; remaining
work is manuscript/co-author integration and coordinated promotion. See
[WORKSPACE_STATUS.md](WORKSPACE_STATUS.md) for current assets, dependencies,
and the reversible archive of superseded prototypes.

Date: 2026-09-22. Review-only layouts requested by the author. This direction
supersedes the proposed placement of the coordinate schematic in Figure 2A,
but does not promote or overwrite the existing publication bundle or the
isolated migration candidate.

## Review of the latest implementation

- All 13 focused migration tests passed, including rejection of incompatible
  Figure 4/5 caches before reading tables or rewriting provenance.
- Figure 4 now checks its context and summary manifest; Figure 5 checks its
  context, canonical manifest, cohort, and companion-file hashes.
- The candidate Figure 3 wrapper again includes the original null-model
  schematic and its caption. The new Figure 2 placement is superseded by the
  author's direction below.
- One additional compatibility regression was found and fixed:
  `figS3_ce_tracking_variance_amendment.render_common_fronts` still treated
  `plot_fronts` as returning only a figure. It now unpacks the figure and
  display metadata. Its figure export was smoke-tested in a temporary
  directory with the saved three common assignments.
- This is a focused review of the fixes, not a new full numerical audit or a
  completed TeX release build. Full wrapper compilation still needs checking
  with a complete TeX installation; the prior attempt lacked `cmex9`.

## Prototype outputs

Run from the repository root in the dev environment:

```bash
MPLCONFIGDIR=/tmp/embryogenesis_mpl_cache python terminal_pareto/prototype_publication_organization.py
```

Outputs are in `output/publication_organization_prototype/`:

| Artifact | Purpose |
|---|---|
| `publication_organization_review.pdf` | Three-page review: amendment, Figure 2, S3 |
| `fig1_endpoint_normalization_amendment.pdf` | Separate component for eventual co-author integration; also PNG and editable-text SVG |
| `fig2_ce_terminal_pareto_front.pdf` | Full-width single panel with no A/B letter |
| `figS3_tracking_pooled_prototype.pdf` | Three-panel tracking/pooled-metric argument |
| `provenance.json` | Input/source hashes, numerical checks, declared scope |
| `*_pct.csv`, `pooled_space_assignments.csv`, `common_assignment_reductions.csv` | Plotted values |

The renderer uses existing assignments. It checks the strict ordered cohort,
reconstructs their costs against current source-derived matrices, checks
permutations and biological-parent capacities, verifies budget feasibility
and saved optimal bounds, and loads the validated production global cache.
Historical expression matrices differ from the current vectorized calculation
only at floating-point roundoff; matrix comparison uses absolute tolerance
1e-12. The existing numerical caches and co-author Figure 1 are not changed.

## Figure 1 amendment and single-panel Figure 2

Export the coordinate/canonical-metric schematic as an independent component,
without a final panel letter. The co-author can incorporate it in Figure 1
when arranging the overall analysis schematic. Until then, call it the
**Figure 1 amendment**, rather than assigning a panel number we do not control.

Suggested amendment caption: **Endpoint coordinates and canonical metrics.**
The travel optimum maps to (0, 1) and the cell-state optimum to (1, 0). For
travel cost T and cell-state cost S, with travel-optimal assignment A and
state-optimal assignment B, the display coordinates are

\[
D_1(a)=\frac{T(a)-T(A)}{T(B)-T(A)},\qquad
D_2(a)=\frac{S(a)-S(B)}{S(A)-S(B)}
\]

The natural lineage L and first-cousin-null mean N use these same anchors.
The closest attained sampled-front assignment to L in this geometry is P*;
d_LP and d_NP are distances from L and N to that same assignment. Position u
is the fraction of front arc length from the travel optimum to P*. Distances
are measured to sampled assignments, not points interpolated between them.
The display transformation does not change optimization. Each subtree uses
its own endpoints for shape/position summaries; comparisons of competing
assignment sets in one cost space must share reference endpoints.

Figure 2 returns to the detailed pooled front as one panel. Its highlighted
maximum-retention assignment remains distinct from the canonical closest
assignment P*. Definitions in Figure 5 should eventually cite the Figure 1
amendment (or its final integrated panel), not Figure 2A.

## Current recommendation: four geometries, four assignment sources (v3)

The author identified the missing comparison in v2: scoring all assignments
only in the pooled metric does not show how the pooled compromise compares
with each embryo's own optimum. The symmetric four-panel layout supplies
that reference directly, without a separate numerical summary or selected
assignment example.

Run `python terminal_pareto/prototype_tracking_cross_geometry.py` in the dev
environment. Outputs are in
`output/publication_organization_prototype/cross_geometry_v3/`:

- `figS3_four_geometries_with_insets.pdf`: current recommendation, one 2-by-2
  page with full fronts and a near-natural zoom inset in each panel.
- `figS3_four_geometries_near_natural.pdf`: enlarged local view, four panels.
- `figS3_four_geometries_full.pdf`: full-range companion for assessing scope.
- `four_geometry_review.pdf`: both views, near-natural first.
- PNG and editable-text SVG versions, `cross_geometry_coordinates.csv`, and
  `provenance.json` with source hashes and all reference endpoints.

Panels A–C measure travel using embryos 1–3, respectively; panel D measures
pooled travel. Each displays the same four assignment sets, optimized using
embryo 1, embryo 2, embryo 3, or pooled travel. Color consistently identifies
the optimization source. A solid line identifies the front optimized for
the panel's metric; dashed lines show assignments transferred unchanged from
the other three sources. Natural lineage is an X in every panel. The local
view uses the same window offsets around natural lineage in each panel;
the full-range companion includes every evaluated point.

The author's subsequent layout revision combines both scales on one page:
full fronts form the four main axes, and upper-right insets show the same
near-natural windows, connected to marked regions in the main axes. Colors,
line styles, assignments, and endpoint transforms are identical at both
scales. The separate local/full exports remain available for inspection.

All four sources now use 301 weighted solutions. Individual-embryo assignments
come from the existing tracking sensitivity cache; pooled assignments come
from the validated migration candidate's global cache. This replaces v2's
mixture of weighted and epsilon-budget sampling. Each panel uses its own
native front's endpoints to transform **all four curves and natural lineage**.
Normalization is never fitted separately to each transferred curve. Axis
values therefore compare assignments within a panel; they are not absolute
cost comparisons across panels. Historical assignment orientation is converted
explicitly, and reconstructed costs, endpoint optima, permutation feasibility,
invariant state costs, and the pooled mean identity are checked before export.

**Reading the result.** Around natural lineage, each embryo's own front is
best for its travel geometry, while assignments optimized in the other embryos
shift away from it. The pooled curve lies closer to the native front than the
other individual-embryo curves in the displayed region. This supports pooling
as a useful compromise for describing the three measured geometries, rather
than making one embryo's geometry the main analysis reference. The full view
also shows that this sensitivity does not erase the common overall front
shape. The pooled front's advantage in panel D is expected from its objective;
the complementary evidence is its position in panels A–C. These are visual
comparisons of sampled curves, not a new exact matched-budget regret estimate
or a claim of uniform superiority throughout all cost ranges.

**Suggested v3 caption.** Geometry dependence of terminal assignments and the
pooled travel compromise. The same 275 terminal edges and protein cosine
costs are used throughout. Colors identify assignment sets optimized using
each of three embryos separately or pooled travel. Travel is then measured
in embryo 1 (A), embryo 2 (B), embryo 3 (C), or the pooled geometry (D), with
assignments held fixed during transfer. Pooled travel is the equal mean of
embryo-specific travel costs divided by their respective natural-lineage
totals. Solid curves are optimized for the displayed geometry; dashed curves
show the other three sources. Each curve connects 301 weighted-sweep solutions;
connecting segments are guides and need not represent attainable assignments.
Every panel applies its native front's endpoint normalization to all curves
and natural lineage (X). Main axes show the full sampled fronts; insets enlarge
the marked regions near natural lineage using the same coordinates. Across the
three measured embryos, the pooled assignments provide a compromise between
their distinct native fronts. Biological and tracking variation are not
separated by this comparison, and three embryos do not establish performance
in unmeasured embryos.

Keep the earlier holdout result (improvement in only 2/12 settings) in the
sensitivity text. Transferred curves are not re-filtered in their target
geometry: their displacement and non-monotonicity are part of the comparison.
The earlier v1/v2 figures and budget-constrained common assignments remain
available as detailed sensitivity records. No optimization cache, accepted
figure, or production wrapper was changed for this layout.

## Earlier prototype: two linked panels (reader-focused v2)

The first three-panel prototype required the reader to switch between an
extreme travel optimum, a near-natural front, and a separate minimax objective.
Its reference also changed from a target optimum to natural lineage, and its
sign convention changed between cost change and cost reduction. The second
prototype reduces this conceptual load rather than merely changing styling.

Run `python terminal_pareto/prototype_tracking_readable.py` in the dev
environment. The PDF, PNG, editable-text SVG, plotted data, and provenance
are in `output/publication_organization_prototype/approachable_v2/`.
`figS3_tracking_readable.pdf` was the second recommendation, superseded by v3. The original
three-panel figure and three-page review bundle are preserved for comparison.

- **Panel A: choose parents using one embryo or all three.** Retain the
  near-natural cost-space comparison, with the three single-embryo curves
  grouped in gray and the pooled curve in teal. The subtitle explicitly says
  that every assignment is evaluated using the same pooled travel metric.
  Natural lineage is 100% on both axes. Highlight the actual pooled assignment
  selected under the no-state-cost-increase constraint with a star.
- **Panel B: follow that same starred assignment.** Measure its travel in each
  embryo without changing any parent choices. Use the same 100% natural
  reference and the same lower-is-better convention as panel A. Show the
  three embryos followed by their average; repeat the star on that average
  to connect it back to panel A. State the mean benefit and embryo-3 increase
  explicitly in words, rather than asking readers to decode signed reductions.

The pooled metric is defined in one sentence above the panels. The endpoint
transfer heatmap and minimax comparison stay in the detailed sensitivity
material. They remain useful analyses, but are unnecessary prerequisites for
understanding the travel metric used in the main article. Gray solid/dashed/
dotted curves denote embryos 1/2/3, respectively; their identities are secondary
to the comparison of single-embryo selection with joint selection.

**Suggested v2 caption.** Tracking dependence and the pooled travel metric.
All analyses use the same 275 terminal edges and top-20 protein cosine costs.
Pooled travel is the equal mean of the three embryo-specific travel costs,
each divided by that embryo's natural travel total. **(A)** Gray curves show
assignments selected using each embryo separately and then evaluated in the
pooled metric; teal shows assignments selected using the pooled metric. Every
curve is displayed in the same cost space, with natural lineage at (100%,
100%). The view is restricted to the region near natural lineage; full pooled
fronts are shown in Figure 2. Lines connect sampled feasible assignments,
not continuously attainable lineages. The star is the pooled-travel optimum
subject to cell-state cost no higher than natural lineage (actual cell-state
cost 99.9495% of natural). **(B)** Travel for that exact assignment measured in
each embryo, with its parent choices held fixed. Natural lineage is 100% in
each geometry. The assignment reduces mean travel by 2.98%, with reductions
in embryos 1 and 2 and a 0.13% increase in embryo 3. The starred average is
the travel coordinate of the star in panel A.

**Interpretive limits remain unchanged.** The gray curves use 301 weighted
solutions each; the pooled curve uses 319 certified budget solves. Do not
interpret their pointwise separation as an exact matched-budget regret.
Pooled optimization performs best in its own objective by construction; the
figure explains the ensemble target and its consequences, rather than proving
that pooling is uniquely correct, removes tracking error, or generalizes to
new embryos. It also does not replace the structural parent-agreement analysis
or quantify full population variability. Keep the existing holdout result
(improvements in only 2/12 settings) in the sensitivity text.

## First S3 prototype: three panels (retained for comparison)

**A. Does selecting one tracking geometry matter?** A 3-by-3 transfer matrix
evaluates each embryo's pure-travel-optimal assignment in every target embryo.
Cells show percentage excess travel over the target's independently computed
travel optimum. Diagonal values are zero; off-diagonal penalties are
16.1–23.5%. This tests an extreme endpoint, where sensitivity is strongest;
it does not summarize the entire trade-off front. Different embryos reflect
both biological and measurement variation, not isolated tracking error.

**B. What changes when we optimize the pooled objective?** A near-natural
cost-space view evaluates each single-embryo front assignment in the same
pooled travel matrix, alongside pooled budget-optimal assignments. Every
horizontal coordinate is mean natural-total-normalized travel, with natural
lineage at zero percent change. Protein cost and the 275-edge cohort are
identical. The full global front is already in Figure 2, so S3 needs only this
local comparison. Percentage axes are deliberate here: they expose actual
cost differences and complement Figure 2's endpoint coordinates.

The native curves use the existing 301 weighted solutions per embryo; the
pooled curve uses 319 certified cell-state-budget solves. These are sampled
feasible assignments; connecting lines are guides, not continuously attainable
lineages. Their pointwise separation is not an exact matched-budget regret
estimate. The pooled front's advantage in its own objective is expected by
construction, not independent evidence that pooling recovers biological truth.

**C. Does the pooled improvement hold in each embryo?** Evaluate one common
assignment per method, optimized with no increase in total cell-state cost,
in all three geometries. Pooled travel falls 2.984% on average, but embryo 3
increases by 0.127%. The worst-embryo (minimax) assignment is retained as a
compact robustness benchmark: mean reduction 2.334%, with reductions of
2.409%, 2.316%, and 2.276% in embryos 1–3. Positive values denote reductions;
negative values denote increases. Neither point is reoptimized for the row
where it is evaluated. The solutions use slightly less than their allowed
cell-state budgets (actual reductions 0.050% and 0.026%).

Suggested S3 caption: **Tracking geometry affects optimized assignments,
motivating an explicit ensemble-average travel objective.** Analyses use the
same 275 terminal edges and fixed top-20 protein cosine costs. (A) Transfer of
pure-travel-optimal assignments between embryos. Entries give excess travel
relative to the target optimum. (B) Single-embryo and pooled assignments
evaluated in the same pooled geometry near natural lineage. Travel is the
equal mean of distances divided by each embryo's global natural travel total;
both axes give percent cost change from natural lineage. Lines connect
sampled assignments. (C) Travel reductions for one pooled and one minimax
assignment under the same no-state-cost-increase constraint, evaluated
unchanged in each embryo. Pooling optimizes the measured-embryo mean and can
trade an increase in one geometry for reductions in others. It remains an
additive edge-cost matrix compatible with the main terminal analysis.
Three embryos do not establish population variability or improvement in new
embryos: the existing leave-one-geometry-out check improved held-out travel
in only 2 of 12 settings for each method.

### What stays outside the concise S3

Keep the existing detailed reviews as sensitivity records: parent-identity
churn, nearest-parent neighborhood overlap, canonical subtree shifts,
whole-front minimax comparison, and all holdout points. Retain the holdout
limitation in the caption/Results even if its plot is omitted. If structural
churn becomes a central manuscript claim, replace or expand panel A with a
biological-parent-agreement display; do not infer it solely from transfer costs.

Pooling is justified by the target estimand (equal-weight average of the three
measured geometries), removal of an arbitrary single-embryo choice, and its
additive compatibility. The figure demonstrates why geometry choice matters
and the consequence of this definition. It does not empirically prove pooling
is the uniquely correct metric, removes noise, or generalizes to new embryos.

## Implementation sequence (completed in the candidate; historical plan)

### Agreed layout for the next iteration

Use
`output/publication_organization_prototype/cross_geometry_v3/figS3_four_geometries_with_insets.pdf`
as the S3 layout reference. This is **one 2-by-2 page**, with full fronts in
the main axes and an upper-right near-natural inset in each panel. The
two-page `four_geometry_review.pdf` and earlier v1/v2 layouts are inspection
records, not the S3 asset to integrate. The layout direction is settled for
implementation; accepted publication outputs have not yet been replaced.

- A–C: travel measured in embryos 1, 2, and 3. D: pooled travel.
- Four assignment sources in every panel, with fixed source colors; solid
  for the native front and dashed for transferred assignments.
- Natural lineage marked by X in main axes and insets; boxes and connectors
  identify the magnified regions. Keep inset coordinates identical to the
  corresponding main axes, without another normalization.
- One shared source legend. Keep numerical reduction summaries, minimax,
  and selected-assignment examples in the detailed sensitivity material.

### Implementation sequence

1. **Checkpoint the current candidate and accepted outputs.** Record hashes
   of analysis caches, assignment arrays, and existing publication assets
   before rebuilding; preserve ignored outputs that would be overwritten.
   Use the isolated `pooled_tracking_v1` candidate for integration. Keep
   legacy no-argument entrypoints and accepted output paths unchanged.

2. **Integrate the S3 renderer and its inputs.** Adapt
   `prototype_tracking_cross_geometry.py` into the candidate publication
   build, using explicit context/run paths instead of its hard-coded
   migration run ID and prototype output directory. Reuse the validated
   301-point individual-embryo and pooled assignment sets; this is a
   presentation integration, not a new optimization. Validate source cohort,
   matrices, sampling configuration, and cache provenance before projection.
   Preserve the historical slot-orientation conversion, fixed state costs,
   pooled mean identity, and target-native endpoint anchors shared by every
   curve and natural lineage. Preserve sweep order and transferred points.
   Export the one-page vector PDF, PNG, editable-text SVG, projection table,
   and provenance into the candidate's output structure. Keep the separate
   full/local views optional diagnostics. Record inset limits in provenance
   (current offsets from natural: travel -0.026/+0.036, state -0.09/+0.09).

3. **Integrate the publication organization and captions.** Update
   `publication_build.py` and `publication_wrappers.py` so candidate S3 uses
   the inset figure and the v3 caption above. Keep panel letters inside the
   composite figure rather than adding a second set in its wrapper. Give
   the Figure 1 amendment a stable standalone stem/label, remove the schematic
   and B label from Figure 2, and update Figure 5's schematic cross-reference
   and build order. Preserve the restored Figure 3A. Leave the co-author's
   Figure 1 artwork untouched. Move explanatory prototype headings/footer
   text into the final caption where this improves manuscript-size legibility;
   retain the source legend, measurement labels, and inset labels in the art.

4. **Validate numerical preservation and artifact identity.** Extend
   `validate_pooled_migration.py` and relevant existing checks to require
   the standalone Figure 1 amendment, single-panel Figure 2, restored
   Figure 3A, Figure 5A/B, and the one-page four-panel S3. Check that no stale
   Figure 2A schematic references remain in candidate wrappers. Verify all
   4,816 source/target/sweep projections against saved assignment costs and
   confirm that inset rendering changes neither coordinates nor underlying
   assignments. Require source hashes, endpoint references, and display
   settings in S3 provenance. Compare checkpoint hashes to confirm unchanged
   analysis caches and accepted assets; run the relevant migration checks.

5. **Compile and inspect at final manuscript size.** Build the complete
   candidate, including the S3 caption, with a working TeX installation
   (the earlier build lacked `cmex9`). Inspect rendered PDFs for inset tick
   legibility, natural-lineage markers, curve visibility, connectors, panel
   labels, and clipping. Confirm S3 fits one page with its caption; trim
   repeated explanatory text before reducing plot or inset font sizes.
   Keep both full geometry and local separation readable. Inspect the
   standalone Figure 1 amendment and single-panel Figure 2 as part of the
   same pass, rather than treating successful prototype export as a complete
   publication build.

6. **Prepare the manuscript handoff, then promote a reviewed bundle.** Update
   the README and `PUBLICATION_FIGURES_HANDOFF.md` with final candidate paths,
   captions, validation results, and the Figure 1 integration dependency.
   Frame S3 around the common overall front shape, tracking-dependent local
   optima, and the pooled compromise visible in A–C; panel D shows its pooled
   objective. Keep the existing holdout limitation in the sensitivity text.
   Prepare corresponding Results/Methods/citation changes for the next
   manuscript iteration, including the 275-edge/42-subtree scope. The author
   coordinates the Figure 1 amendment with the co-author and resolves its
   final panel number. Promote accepted outputs only after review of the
   coherent candidate bundle.

### Completion criteria for that iteration

- Candidate S3 is a single 2-by-2 page with four readable near-natural insets
  and its matching caption; no older prototype is selected by the build.
- Figure 1 amendment, single-panel Figure 2, and updated cross-references
  are present in the candidate; Figure 3A remains included.
- Projection/provenance checks and relevant migration checks pass; analysis
  cache hashes and accepted outputs remain unchanged during candidate work.
- The compiled candidate has been visually inspected and its handoff records
  any remaining manuscript/co-author integration work.

No manuscript prose, co-author artwork, accepted figures, or production
wrapper organization was changed by this prototype pass.

## Implementation checkpoint, 2026-09-22

The agreed organization has now been integrated into the isolated
`pooled_tracking_v1/migration_candidate_20260920` publication directory;
this changes candidate wrappers only, not the accepted release. The candidate
has a standalone, letter-free Figure 1 amendment component and wrapper,
single-panel Figure 2, restored Figure 3A, two-panel Figure 5, and the selected
one-page 2-by-2 S3 with four full fronts and connected near-natural insets.
The final S3 wrapper uses the v3 caption; older prototypes remain review
records and are not included by the candidate build.

The candidate endpoint directory contains the compiled
`fig1_ce_endpoint_normalization_amendment.pdf`,
`fig2_ce_terminal_pareto_main.pdf`, and
`figS3_ce_tracking_robustness.pdf`, as well as the S3 component
`figS3_four_geometries_with_insets.{pdf,png,svg}`,
`cross_geometry_coordinates.csv`, and `provenance.json`. Every S3 panel uses
301 saved source assignments, its own native endpoint anchors for all four
curves, and the declared inset offsets. The 4,816 target/source/sweep
projections replay to a maximum absolute error of
\(4.55\times10^{-13}\). All 29 checks in
`output/runs/pooled_tracking_v1/migration_candidate_20260920/validation/migration_validation.md`
pass. The pre-organization SHA-256 checkpoint there confirms unchanged
analysis caches, tracking inputs, and accepted publication assets. All
candidate wrappers compile as single-page PDFs; Figure 1, Figure 2,
Figure 5, and S3 were inspected at manuscript size for legibility and clipping.

Use `publication_build.py --profile pooled_tracking_v1 --run-id
migration_candidate_20260920 --layout-only` for a layout-only rebuild from
validated caches. Co-author Figure 1 integration, manuscript revision, and
review of the coherent candidate bundle still precede promotion. See
`README.md` and the repository-level `PUBLICATION_FIGURES_HANDOFF.md` for the
handoff.
