# Joint implementation plan: pooled travel and endpoint-normalized figures

Date: 2026-09-20. The author has selected pooled travel as the direction for
the main terminal-only analysis and requested an implementation plan that
preserves existing pipelines. The author subsequently requested a combined
plan for pooled travel and endpoint-normalized presentation of suitable Pareto
fronts. This document supersedes the pooled-only version of the plan rather
than introducing a second migration plan.

**Implementation checkpoint, 2026-09-20:** stages 0--4 are complete in the
isolated candidate run
`output/runs/pooled_tracking_v1/migration_candidate_20260920/`. The accepted
root-level publication bundle and no-argument legacy entrypoints have not been
switched. Stage 5 remains the normal figure/manuscript review and coordinated
promotion step.

**Organization update, 2026-09-22:** the subsequent directions in
`PUBLICATION_ORGANIZATION_PROTOTYPE.md` supersede this plan's earlier Figure
2A/B layout. The isolated candidate now has a standalone Figure 1 amendment,
single-panel Figure 2, and one-page four-geometry Figure S3. Candidate wrappers
were compiled with the available TeX engine and inspected; the historical
statement below that compilation was unavailable applied to the first build,
not the current candidate. All migration and projection checks pass; accepted
outputs remain unchanged. See the README and publication handoff for current
paths, validation, and remaining manuscript/co-author integration.

The implementation includes the three declared profiles, source-derived
strict-intersection matrices, profile-keyed numerical caches, all three global
display modes, downstream Figures 4--6 and S1--S3, Table 1, candidate wrappers,
and a three-column validation report. Reproduce the isolated candidate with:

```bash
python terminal_pareto/publication_build.py \
  --profile pooled_tracking_v1 \
  --run-id migration_candidate_20260920 \
  --no-compile
python terminal_pareto/validate_pooled_migration.py \
  --run-id migration_candidate_20260920
```

Omit `--no-compile` when a supported TeX engine is installed. This environment
had no TeX engine, so the panel PDFs were rendered and inspected directly and
the standalone wrapper sources were generated but not compiled.

**Review fixes, 2026-09-21:** legacy Figure 6B--C once again defaults to its
accepted null-SD coordinates, while the pooled coordinator requests endpoint
display explicitly. Figure 6A/S2 reuse validates a dedicated cache manifest
before reading tables or replacing context provenance. The pooled Figure 2
wrapper now places the endpoint/canonical schematic in panel A beside the wider
front in panel B, and Figure 5 contains the two subtree-summary panels. The
caption distinguishes the closest canonical assignment (P^*) from the
maximum-retention assignment highlighted on the global front. The full-random
inset now uses padding proportional to its own displayed range.

**Review fixes, 2026-09-22:** Figure 4 and Figure 5 reusable tables now carry
dedicated identity-and-hash manifests, and both downstream renderers validate
the pre-existing context manifest before any provenance rewrite or table load.
The pooled Figure 3 wrapper restores the existing null-model schematic as
panel A. Figure 2 now stacks a 68%-text-width schematic above the full-width
front so the explanatory labels remain legible at manuscript scale.

Scientific evidence and executable comparison are recorded in
`TRACKING_METRIC_COMPARISON.md`. The authoritative module record is `README.md`.

## Two changes, independently verifiable

1. **Analysis change:** replace primary embryo-1 travel with pooled normalized
   travel on the shared cohort. This changes costs, feasible cohort, selected
   assignments, and potentially scientific conclusions.
2. **Presentation change:** display suitable fronts in endpoint coordinates.
   For any fixed analysis result this changes only coordinates, labels and
   reference markers, not assignments, costs, null draws, or canonical metrics.

Keep three distinct operations explicit in code and metadata:

| Operation | Definition | Changes optimization? |
|---|---|---|
| Embryo aggregation | Mean of edge distances divided by each embryo's global natural total | Yes: defines the new travel objective |
| Weight-sweep scaling | Existing first-cousin-null SD convention and configured weight grid | Keep unchanged by the display work; exact/sampled moment policy remains an explicit analysis setting |
| Plot normalization | Affine transformation using a declared reference front's endpoints | No: render a saved analysis result |

Do not replace the optimizer's weight normalization with endpoint spans merely
because the axes change. Although rescaling objectives preserves Pareto
dominance, it can change the assignments sampled by a fixed weight grid.

## Scientific decision and interpretation

Use the equal mean of the three **natural-total-normalized edge-distance
matrices**, the pooled definition already evaluated in the comparison:

\[
\overline d_{ij}=\frac{1}{3}\sum_{r=1}^{3}
\frac{d_{ij}^{(r)}}{T_r(L)}
\]

Keep top-20 protein cosine costs, terminal-parent capacities, the null family,
and canonical metric definitions. Use the strict shared natural-edge cohort
with cutoffs 255, 247, and 225. The current inputs yield 275 edges and 42
qualifying subtrees; these are versioned regression expectations, not universal
constants for future datasets. Retain minimax and individual-embryo analyses
as sensitivity analyses, rather than making minimax a matrix-valued option.

Three embryos are insufficient to characterize population variability, and
each holdout fit uses only two geometries. This can plausibly contribute to
unstable transfer, but the existing data do not establish that sample size
caused the observed failures. Describe pooled travel as an ensemble metric
of the three measured geometries. Do not claim that averaging has recovered
a noise-free embryo or that optimized assignments generalize to new embryos.
The choice of pooling rests on the scientific target and additive structure,
not on its producing more natural-lineage points on sampled fronts.

## Architecture: change the inputs, preserve the mathematical engine

Introduce one small shared context module, provisionally
`analysis_context.py`, containing an analysis specification, a builder, and
output-path resolution. This is an input adapter, not a new optimizer.

The specification identifies tracking files/cutoffs, the edge-cohort rule,
expression representation, travel aggregation and normalization, null/scaling
policy, sweep settings, seed, and output root. Initially support three explicit
profiles:

| Proposed profile | Cohort | Travel | Purpose |
|---|---|---|---|
| `embryo1_legacy` | Existing embryo-1 cohort, currently 299 | Existing embryo-1 distance | Reproduce accepted pipeline |
| `embryo1_matched` | Strict three-embryo intersection, currently 275 | Embryo-1 distance on shared edges | Isolate the effect of coverage |
| `pooled_tracking_v1` | Same strict intersection | Mean normalized distance | New primary terminal target |

Return a problem/context with:

- ordered `(child, natural_parent)` edges, duplicate parent slots/capacities,
  cell identities and types, and full reference lineage;
- expression and travel matrices in that exact ordering;
- the three component travel matrices and fixed global natural totals;
- eligibility, exclusion, and subtree manifests;
- an explicit profile/run identifier and provenance manifest.

Build production inputs from the source tracking/expression/lineage data.
The exploratory NPZ is a regression fixture, not a production dependency.
Do not import the exploratory comparison or its MILP driver to construct
ordinary publication costs. Reuse verified selection logic by extracting it
into the shared builder and retaining compatibility adapters where needed.

Build the strict intersection of **natural parent-child edges**, not merely
child names. Preserve reference traversal order and biological parent-slot
multiplicities. Derive subtrees from the full reference tree, then intersect
their terminal edges with the profile cohort; do not prune the tree and
discover a different set of terminal cells.

Subtree and cell-type problems take indexed submatrices of the global costs.
Keep the three global normalization factors fixed: normalizing each embryo
again within every subtree would change its weight. The pooled natural total
is one for global P0; subtree natural totals are generally not one.

Keep existing matrix-based functions in `pareto_engine.py` and
`lineage_metrics.py` compatible. Preserve `build_cost_matrices(...)` for
single-embryo, RNA, cross-species, and external callers. Retain existing CSV
columns, including historical `xyz` names where required by readers; put
metric definitions and dimensionless units in profile metadata and labels.

## Shared display layer and reference policy

Add a small pure display module, provisionally `front_coordinates.py`, beside
the analysis context. Keep analysis profiles independent of display modes.
Proposed display choices are `endpoint`, `null_sd`, and `percent_natural`;
existing entrypoints retain their existing default until the new coordinated
publication build explicitly selects its display policy.

For the reference travel optimum \(A\) and reference state optimum \(B\), use

\[
X(p)=\frac{T(p)-T(A)}{T(B)-T(A)},
\qquad
Y(p)=\frac{S(p)-S(B)}{S(A)-S(B)}
\]

Thus \(A=(0,1)\), \(B=(1,0)\). Natural lineage is plotted at its transformed
position, not forced to the origin. Its nearby percentage-improvement panel
can still use natural lineage as the origin. These panels must label their
different coordinates explicitly.

The transformation consumes raw costs, stored endpoint assignment IDs/costs,
and a reference-analysis identifier; it returns transformed coordinates and
the transform metadata. Apply the same transform to every assignment, natural
lineage, and null sample in a comparison panel. Preserve raw costs and null
draws so rendering can be changed without optimization or resampling. Reuse
the established canonical endpoint convention; do not normalize already
normalized Figure 5 coordinates again.

Endpoint ties require an explicit recorded anchor-selection rule. Initially
reuse the endpoints from the validated analysis run, consistently for both
canonical metrics and display. A later secondary-objective tie-break that
changes those endpoints is an analysis change with its own comparison, not
a cosmetic renderer fix. Validate positive spans with scale-aware tolerances;
report a degenerate endpoint case and offer a clearly labeled alternative
view rather than dividing by zero or silently substituting another scale.
Do not clip natural lineage, nulls, or transferred assignments to the unit
square; valid observations may lie outside it.

### Figure-level policy

| Figure / purpose | Planned display and reference |
|---|---|
| Figure 2 main pooled front | Endpoint coordinates from pooled P0; natural lineage and all nulls use those same anchors; retain a percentage-saving zoom and null-SD diagnostic where useful |
| Figure 3 cost-space panels | Same pooled P0 anchors when evaluating global assignments; lineage-distance, retention and other non-cost axes retain their definitions |
| Figure 4 lineage map | No coordinate-normalization change; update cohort and analysis-derived labels only |
| Figure 5 / Table 1 | Preserve established canonical endpoint coordinates and metrics; refresh pooled results rather than redefine them |
| Figure S1 null-relative evidence | Preserve its explicitly null-relative statistic and appropriate null-SD views |
| Figure 6A and S2 retention/cost ledger | Preserve retention, arc-length and interpretable cost/reduction units; do not force endpoint axes onto a ledger or heatmap |
| Figure 6B--C restricted versus unrestricted costs | A shared unrestricted reference for direct performance comparisons on the same cohort; only use each type's own endpoints in explicitly separate shape-comparison facets |
| Figure S3 transfer panels | Within each target geometry, use that target's native front as the shared reference for native, transferred, pooled and minimax assignments evaluated there |
| Pooled versus minimax performance panels | First evaluate both sets of assignments under the displayed objective; use one reference front for that objective, or percentage changes for the practical cost comparison |
| Cross-subtree shape comparisons | Each subtree may use its own endpoints, explicitly labeled as shape normalization; do not interpret coincident endpoints as equal absolute performance |

Different objectives or geometries must not be overlaid as though their costs
were interchangeable. Independent normalization of each overlaid curve is
acceptable only for explicitly labeled shape comparison. It must not conceal
performance differences in the main metric/transfer comparisons.

### Cache separation

Keep numerical analysis caches keyed by the analysis specification only.
Figure artifacts additionally record display mode, reference run/assignment
IDs, endpoint costs, transform version, and clipping/axis limits. Place
alternative renders in separate display directories within a run, so an
endpoint render cannot overwrite a null-SD render under the same identity.
Changing display mode must not rerun the optimizer, change raw arrays, or
invalidate a valid numerical cache.

## Implementation stages and exit checks

### 0. Preserve the baseline and define regression fixtures

- Inventory current source changes, numerical caches, figure panels, and TeX
  wrappers. Keep unrelated changes separate.
- Archive accepted outputs and the exploratory tracking/comparison checkpoints
  with a file-hash manifest. These files are Git-ignored; a source commit alone
  is not a backup.
- Capture deterministic legacy costs, fronts, canonical tables, type counts,
  and the current validation result in an isolated run directory.
- Preserve the old source/provenance relationship before editing files whose
  hashes are embedded in diagnostic caches. Do not rewrite historical hashes
  to make a changed source file appear to reproduce an old result.

**Exit:** baseline artifacts and source references are recoverable, and the
expected legacy versus matched/pooled results are explicitly distinguished.

### 1. Add the shared builder and explicit profiles

- Implement the three profiles, ordered matrix access, cohort manifests,
  global normalization, and lineage/type metadata.
- Verify raw reconstruction against the existing matched matrices and
  `tracking_metric_comparison/candidate_travel_matrices.npz`.
- Preserve no-argument behavior of existing script entrypoints as legacy.
  Add opt-in profile/context arguments rather than changing
  `data_loader.CE_TRACKS_PATH`, `T_CE`, or the global meaning of tracking loaders.
- Use the pooled profile in the new coordinated publication build after
  validation; documentation will identify that build as the primary route.
  Existing legacy commands remain a supported reproduction route.

**Exit:** the legacy profile reproduces current costs; pooled matrix sums
equal the mean of the three evaluated travel ratios for actual assignments.
No synthetic coordinates or altered matching algorithm are introduced.

### 2. Isolate caches and make the global analysis use the context

Route new builds under a profile-specific run directory, for example
`output/runs/pooled_tracking_v1/<run-id>/{analysis,publication,validation}/`.
Within it, keep familiar artifact filenames. Preserve legacy output locations
for legacy entrypoints. All readers, writers, and wrappers receive their
paths from the same run context.

The cache identity must include profile, ordered edge/feature identifiers,
input hashes, cutoffs, aggregation/normalization, matrices, null/scaling policy,
seed, and sweep configuration. Reject mismatched or incomplete caches; do not
fall back to a root-level legacy cache when a pooled artifact is missing.

Migrate Figures 2--3 first. Retain matrix-based optimization and tree-distance
calculations. Recompute nulls from pooled costs using shared assignments.
For the pooled production profile, use exact first-cousin moments for scaling
and sampled assignments for displayed clouds. Preserve legacy scaling in
legacy mode: the current Figures 2--3 loader estimates its reference moments
from 1,000 draws, whereas canonical subtree calculations use exact moments.
Record this deliberate pooled scaling policy; do not silently change legacy
results or confound metric and scaling comparisons.

**Exit:** global pooled outputs, all null families, edge retention and
structural-cost panels replay correctly; the existing profile remains unchanged.

### 2a. Implement and verify display normalization on fixed results

- Build the pure endpoint transform and metadata contract before changing
  individual renderers. Reuse the canonical formulas and reference anchors.
- Render a preserved legacy result in both existing and endpoint coordinates
  as a display-only regression case; do not recompute its analysis.
- Render the validated pooled P0 result in null-SD, endpoint and percentage
  coordinates from one numerical cache. Use this as the Figure 2 presentation
  prototype before migrating all suitable panels.
- Show natural lineage, endpoint labels and transformed nulls consistently;
  retain an appropriate zoom/inset rather than hiding distant null points.

**Exit:** raw costs, assignment IDs and canonical metrics are identical between
display modes; endpoint mapping and inverse transforms pass. The prototype
communicates both trade-off geometry and actual savings over natural lineage.

### 3. Migrate downstream terminal analyses in dependency order

| Files / consumers | Required change |
|---|---|
| `subtree_analysis.py` | Context/submatrix input; recompute cohort-specific null groups, types, summaries and rare-tail/optimality outputs |
| `fig5_table1_ce_canonical_metrics.py` | Context-aware subtree enumeration and analysis; explicit paths for every table/cache writer and self-test |
| `fig4_ce_subtree_map.py` | Use the same cohort, types and eligibility manifest as its summary cache |
| `fig5_figs1_ce_canonical_summary.py` | Read validated run-specific metrics for Figure 5 and S1 |
| `subtree_explore.py` | Accept prepared matrices for global-front cell-type decompositions; retain legacy coordinate-call compatibility |
| `fig6a_figs2_ce_cell_types.py` | Regenerate retention and endpoint caches from the pooled global front; audit count-dependent small-type merging |
| `fig6bc_ce_within_type.py` | Apply existing type restrictions to pooled submatrices; preserve parent capacities and aggregation accounting |
| `figS3_ce_tracking_robustness.py` and amendment diagnostics | Keep individually identified geometries; compare with the new primary reference without replacing component costs by pooled costs |
| `main.py` / notebook consumers | Expose an explicit CE-protein profile and adapt shared helpers; leave RNA, early-stage and CB choices explicit |

The broad notebook is not a prerequisite for replacing shared publication
loaders, but its affected helper calls and CE-protein paths must be checked
before promotion. Two-dimensional, z-noise, and random-feature controls need
an explicit pooled definition before being described as controls for the new
primary metric. For pooled geometry perturbations, perturb each component
geometry before combining costs; record whether normalization is fixed to
the unperturbed baseline. Unmigrated controls retain their legacy labels.

Migrate display consumers according to the figure-level policy above once
their numerical dependencies use the shared context. Add display options at
renderer boundaries, not inside assignment or null-generation functions.

**Exit:** Figure 4, canonical tables, and cell-type totals all agree on 275
edges/42 eligible subtrees for these inputs. Restrictions and perturbations
use the selected profile's costs consistently. The completed 42-subtree pilot
is reproduced; the remaining publication analyses are newly regenerated.

### 4. Validate the complete build and review changes

Use meaningful compatibility and scientific checks:

1. **Legacy regression:** compare cost arrays, objective totals, deterministic
   tables and pipeline outputs before/after refactoring. Compare biological
   parents rather than duplicate slot labels; accept alternate tied solutions
   only after verifying equal objective values and capacities.
2. **Pooling identities:** a one-embryo specification reproduces its normalized
   matrix; three identical geometries give that same normalized matrix;
   permuting replicate order changes nothing; multiplying one embryo's
   distances and its natural total by the same positive scalar changes nothing.
3. **Cohort/submatrix checks:** no missing identifiers or non-finite costs;
   preserved parent capacities; subtree/type costs equal the appropriate
   globally normalized submatrix evaluations.
4. **Null checks:** enumerate small cousin groups to verify moments on the
   pooled matrix, and check shared-permutation simulations. Do not average
   standard deviations or simulate independent assignments across embryos.
5. **Front checks:** feasibility and cost replay, canonical endpoint/arc-length
   definitions, natural-to-front distance to actual sampled assignments, and
   equality of pooled sums and component-average costs.
6. **Cache/output checks:** reject a legacy artifact in a pooled run even if
   dimensions agree; exercise missing caches, explicit temporary output roots,
   and a full pipeline run that cannot write to accepted output directories.
7. **Visual/manuscript checks:** render every new PDF and check numbers, units,
   captions, lineage/type counts and wrapper input paths.
8. **Display invariants:** reference endpoints map to (0,1)/(1,0); affine
   inversion recovers costs; assignment IDs, raw null draws, canonical d_LP/u_L
   and dominance relations are unchanged for a fixed result. Test a natural
   point away from the origin and a transferred/null point outside the unit
   square. Test ties and degenerate spans explicitly.
9. **Reference consistency:** every curve and null cloud in a performance
   panel has the same reference identifier. Switching display mode leaves
   numerical cache hashes untouched and creates a distinct figure artifact.

Port the canonical self-tests to accept context and explicit paths. Do not
change all hard-coded legacy expectations from 43 to 42: keep separate profile
fixtures. Specifically remove dependence on import-time captured output
defaults such as `write_curves_npz(..., out_dir=ANALYSIS_OUT)` when executing
isolated tests; redirecting a module global alone is insufficient.

Use three comparison columns throughout the report: legacy embryo 1 (299),
matched embryo 1 (275), pooled (275). Compare travel aggregation with the
same null/scaling convention when attributing changes to the metric. Preserve
the existing evidence that some subtree conclusions change substantially.

Use a small rendering comparison matrix to isolate the two requested changes:

| Numerical analysis | Existing/null-SD view | Endpoint view |
|---|---|---|
| Legacy embryo 1, 299 edges | Frozen baseline | Same saved result, new transform only |
| Matched embryo 1, 275 edges | Coverage control | Same shared-cohort control in endpoint coordinates |
| Pooled, 275 edges | Aggregation control | Target primary front presentation |

Each row shares the same assignments between its two views. Each column's
cross-profile comparisons must identify the reference geometry and scale;
the matrix is a validation/reporting aid, not permission to compare independently
normalized coordinate differences as absolute savings.

**Exit:** complete candidate build and comparison report pass, with no mixed
profiles, unexplained legacy regressions, or unreviewed numerical drift.

### 5. Promote the coordinated publication build

- Make the validated pooled build the documented primary terminal release,
  with minimax and replicate transfer as sensitivity material.
- Regenerate Figures 2--6, S1--S3, Table 1 and their source captions/wrappers
  consistently, including the 275/42 cohort and the figure-level display policy.
  Label endpoint units as fractions of endpoint cost spans, percentage changes
  relative to nature as percentages, and null-SD views as null standard
  deviations. These three scales must not be described interchangeably.
- Update manuscript methods and every affected numerical/subtree statement;
  retain the limited-three-embryo interpretation and observed holdout findings.
- Promote a complete run through one release selection/copy step only after
  checking all inputs and rendered outputs. Keep the previous release and
  its manifest available, so rollback selects the old bundle rather than
  mixing individual old/new panels.

The author has chosen the pooled direction and requested the joint
normalization migration. This plan does not add a new
permission gate to ordinary implementation or validation. Final figure
presentation still receives the normal manuscript review before being called
accepted; numerical success alone does not settle layout or narrative.

## Suggested implementation checkpoints

Keep changes small enough to review and revert independently:

1. **Baseline and configuration:** archive + context/profile builder + identity
   and legacy regression tests.
2. **Pooled analysis:** explicit paths/cache manifests + global pooled build
   evaluated in the existing display convention to inspect scientific changes.
3. **Display layer:** pure transforms + unchanged-result tests + Figure 2
   prototype with endpoint axes and percentage/null-relative companion views.
4. **Downstream integration:** subtree/table, cell-type, restricted-front and
   sensitivity consumers, applying display choices panel by panel.
5. **Release verification:** complete two-change comparison matrix, all
   numerical/visual checks, and coordinated figures/captions/manuscript update.

Start with checkpoint 1. Do not begin by changing the global tracking path or
overwriting `output/publication`; those shortcuts would leave independent
loaders and cached consumers using different scientific configurations.
