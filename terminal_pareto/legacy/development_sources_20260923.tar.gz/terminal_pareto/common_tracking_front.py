"""Sample the shared minimax travel/state front with bounded, resumable solves.

Uses LP reduced costs to exclude edges that cannot beat a known feasible
assignment, then solves the remaining integer problem. All bounds, actual
assignments, and incomplete solves are retained. No publication files change.
"""
import argparse
import hashlib
import itertools
import json
import multiprocessing as mp
from pathlib import Path
import time
import warnings

import numpy as np
import pandas as pd
import scipy
from scipy.optimize import Bounds, LinearConstraint, linear_sum_assignment, linprog, milp
from scipy.sparse import coo_matrix, csr_matrix, vstack

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / 'terminal_pareto/output/tracking_geometry_sensitivity/assignments_and_costs.npz'
OUT = ROOT / 'terminal_pareto/output/common_tracking_assignment/dense_front'
REPS = ['embryo1', 'embryo2', 'embryo3']


def costs(a, t, e, nt):
    travel = t[:, a, np.arange(e.shape[1])].sum(axis=1)
    state = e[a, np.arange(e.shape[1])].sum()
    return travel, state, np.max(travel / nt)


def solve(t, e, capacity, nt, ns, budget, pool, seconds):
    """Minimize worst travel ratio at a fixed state budget, with safe pruning."""
    m, n = e.shape
    nv = m * n
    eligible = [(costs(a, t, e, nt)[2], a) for a in pool
                if costs(a, t, e, nt)[1] <= budget + 1e-8]
    incumbent, fallback = min(eligible, key=lambda pair: pair[0])
    idx = np.arange(nv)
    equal = coo_matrix((np.ones(2 * nv),
                       (np.r_[np.repeat(np.arange(m), n), m + np.tile(np.arange(n), m)],
                        np.r_[idx, idx])), shape=(m + n, nv + 1)).tocsr()
    rhs = np.r_[capacity, np.ones(n)]
    inequalities = csr_matrix(np.vstack((
        np.column_stack((t.reshape(3, nv) / nt[:, None], -np.ones(3))),
        np.r_[e.ravel() / ns, 0])))
    upper = np.r_[np.zeros(3), budget / ns]
    c = np.r_[np.zeros(nv), 1.]
    bounds = np.column_stack((np.zeros(nv + 1), np.r_[np.ones(nv), np.inf]))
    # HiGHS options forwarded by SciPy; one thread avoids severe oversubscription.
    options = dict(time_limit=seconds, threads=1)
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', message='Unrecognized options detected')
        lp = linprog(c, A_ub=inequalities, b_ub=upper, A_eq=equal, b_eq=rhs,
                     bounds=bounds, method='highs', options=options)
    if not lp.success:
        return dict(assignment=fallback.tolist(), status='lp_incomplete',
                    lower_bound=None, message=lp.message, active_edges=nv)
    full_matrix = vstack((equal, inequalities), format='csc')
    low = np.r_[rhs, np.full(4, -np.inf)]
    high = np.r_[rhs, upper]

    def integer_solve(allowed, limit):
        selected = np.r_[np.flatnonzero(allowed), nv]
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore', message='Unrecognized options detected')
            result = milp(c[selected], integrality=np.r_[np.ones(len(selected) - 1), 0],
                          bounds=Bounds(bounds[selected, 0], bounds[selected, 1]),
                          constraints=LinearConstraint(full_matrix[:, selected], low, high),
                          options=dict(time_limit=limit, threads=1, mip_rel_gap=1e-8))
        candidate = None
        if result.x is not None:
            flat = np.zeros(nv)
            flat[selected[:-1]] = result.x[:-1]
            np.testing.assert_allclose(flat, np.round(flat), atol=1e-5, rtol=0)
            binary = np.round(flat).astype(int).reshape(m, n)
            assert np.array_equal(binary.sum(axis=1), capacity)
            assert np.array_equal(binary.sum(axis=0), np.ones(n))
            candidate = binary.argmax(axis=0)
            assert costs(candidate, t, e, nt)[1] <= budget + 1e-5
        return result, candidate

    # First obtain a better feasible incumbent on LP-support + fallback edges.
    # This is a heuristic only: its restricted solver bound is never reported
    # as a global bound. The next solve uses provably safe reduced-cost fixing.
    support = lp.x[:-1] > 1e-8
    support[fallback * n + np.arange(n)] = True
    _, candidate = integer_solve(support, min(2., seconds))
    if candidate is not None and costs(candidate, t, e, nt)[2] < incumbent:
        fallback = candidate
        incumbent = costs(candidate, t, e, nt)[2]

    # At x_j=0, the lower-bound reduced cost is the LP penalty for choosing
    # that edge. If it exceeds incumbent - LP optimum, no better solution
    # can contain the edge. Keep a generous absolute tolerance and fallback.
    allowed = (lp.x[:-1] > 1e-8) | (lp.lower.marginals[:-1] <= incumbent - lp.fun + 1e-7)
    allowed[fallback * n + np.arange(n)] = True
    result, candidate = integer_solve(allowed, seconds)
    assignment = fallback
    if candidate is not None:
        _, state, worst = costs(candidate, t, e, nt)
        assert state <= budget + 1e-5
        if worst <= incumbent + 1e-9:
            assignment = candidate
    bound = getattr(result, 'mip_dual_bound', None)
    # Excluded integer solutions cannot improve on the original incumbent.
    lower = max(float(lp.fun), min(incumbent, float(bound))) if bound is not None else float(lp.fun)
    actual = costs(assignment, t, e, nt)[2]
    assert lower <= actual + 1e-7
    return dict(assignment=assignment.tolist(), status='optimal' if result.status == 0 else 'time_limit',
                lower_bound=lower, lp_lower_bound=float(lp.fun),
                absolute_gap=max(0., actual - lower), solver_status=int(result.status),
                message=result.message, active_edges=int(allowed.sum()),
                original_edges=nv)


def worker(connection, args):
    try:
        connection.send(solve(*args))
    except Exception as error:
        connection.send(dict(status='error', message=repr(error)))
    finally:
        connection.close()


def bounded_solve(t, e, cap, nt, ns, budget, pool, seconds):
    ctx = mp.get_context('fork')
    parent, child = ctx.Pipe(duplex=False)
    process = ctx.Process(target=worker, args=(child, (t, e, cap, nt, ns, budget, pool, seconds)))
    process.start()
    child.close()
    if parent.poll(2 * seconds + 15):
        result = parent.recv()
    else:
        result = dict(status='wall_timeout', message='External process time limit reached')
    process.join(timeout=1)
    if process.is_alive():
        process.kill()
    process.join(timeout=5)
    assert not process.is_alive(), 'Worker failed to exit after kill'
    parent.close()
    if 'assignment' not in result:
        feasible = [a for a in pool if costs(a, t, e, nt)[1] <= budget + 1e-8]
        result['assignment'] = min(feasible, key=lambda a: costs(a, t, e, nt)[2]).tolist()
        result['lower_bound'] = None
    return result


def load_problem():
    data = np.load(CACHE)
    parents = data['natural_parents']
    names, first, inverse, cap = np.unique(parents, return_index=True, return_inverse=True,
                                          return_counts=True)
    raw = np.array([data[r + '_travel_matrix'] for r in REPS])
    t, e = raw[:, first], data['expression_matrix'][first]
    np.testing.assert_array_equal(raw, t[:, inverse])
    np.testing.assert_array_equal(data['expression_matrix'], e[inverse])
    nt, ns = np.trace(raw, axis1=1, axis2=2), np.trace(data['expression_matrix'])
    pool = [inverse]
    for r in REPS:
        pool.extend(inverse[np.argsort(a)] for a in data[r + '_assignments'])
    for folder in [OUT.parent, OUT.parent / 'expression_tradeoff']:
        edges = pd.read_csv(folder / 'common_assignments.csv')
        for _, group in edges.groupby('expression_reduction_required_pct'):
            assert np.array_equal(group.child, data['children'])
            pool.append(np.searchsorted(names, group.common_parent))
    # Independently establish the state minimum rather than assuming a cached
    # weighted-sweep endpoint is correct.
    expanded_parents = np.repeat(np.arange(len(cap)), cap)
    slots, child_indices = linear_sum_assignment(e[expanded_parents])
    state_minimizer = np.empty(len(parents), dtype=int)
    state_minimizer[child_indices] = expanded_parents[slots]
    pool.append(state_minimizer)
    pool = list(np.unique(pool, axis=0))
    return data, names, cap, t, e, nt, ns, pool


def selftest():
    rng = np.random.default_rng(17)
    cap = np.array([2, 1, 1])
    natural = np.array([0, 0, 1, 2])
    assignments = np.unique(list(itertools.permutations(natural)), axis=0)
    for repeat in range(5):
        t = rng.uniform(.1, 1, (3, 3, 4))
        e = rng.uniform(.1, 1, (3, 4))
        nt = t[:, natural, np.arange(4)].sum(axis=1)
        ns = e[natural, np.arange(4)].sum()
        states = np.array([costs(a, t, e, nt)[1] for a in assignments])
        # Give the solver only one feasible incumbent, not the known optimum.
        for budget in [states.min(), np.median(states), states.max()]:
            feasible = assignments[states <= budget + 1e-10]
            res = solve(t, e, cap, nt, ns, budget, [feasible[0]], 10)
            exact = min(costs(a, t, e, nt)[2] for a in feasible)
            np.testing.assert_allclose(costs(np.array(res['assignment']), t, e, nt)[2], exact, atol=1e-7)
            assert res['lower_bound'] <= exact + 1e-7
            assert res['absolute_gap'] < 1e-7
    print('15 exhaustive budget solves passed, including reduced-cost pruning.', flush=True)


def run(out, intervals, seconds):
    out.mkdir(parents=True, exist_ok=True)
    data, names, cap, t, e, nt, ns, pool = load_problem()
    records_path = out / 'solver_records.json'
    if records_path.exists():
        prior = json.loads((out / 'provenance.json').read_text())
        assert prior['cache_sha256'] == hashlib.sha256(CACHE.read_bytes()).hexdigest()
        assert prior['source_sha256'] == hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), \
            'Source changed: use a new output directory'
    records = json.loads(records_path.read_text()) if records_path.exists() else []
    provenance = dict(cache=str(CACHE), cache_sha256=hashlib.sha256(CACHE.read_bytes()).hexdigest(),
                      source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                      numpy=np.__version__, scipy=scipy.__version__, intervals=intervals,
                      seconds_per_solver=seconds, hard_seconds_per_point=2 * seconds + 21,
                      definition='min max_r T_r(A)/T_r(natural), subject to S(A)<=budget',
                      complete_discrete_front=False)
    (out / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    for row in records:
        pool.append(np.array(row['assignment']))

    def point(budget, name):
        previous = next((r for r in records if r['point_id'] == name), None)
        if previous is not None:
            return previous
        start = time.monotonic()
        print('Starting', name, flush=True)
        result = bounded_solve(t, e, cap, nt, ns, budget, pool, seconds)
        a = np.array(result['assignment'])
        travel, state, worst = costs(a, t, e, nt)
        assert np.array_equal(np.bincount(a, minlength=len(cap)), cap)
        assert state <= budget + 1e-5
        result.update(point_id=name, budget=float(budget), expression=float(state),
                      expression_natural=float(ns), worst_travel_ratio=float(worst),
                      guaranteed_travel_reduction_pct=float(100 * (1 - worst)),
                      elapsed_seconds=time.monotonic() - start,
                      natural_edge_retention=float(np.mean(names[a] == data['natural_parents'])))
        for r, cost, nat in zip(REPS, travel, nt):
            result[r + '_travel'] = float(cost)
            result[r + '_natural_travel'] = float(nat)
        pool.append(a)
        records.append(result)
        records_path.write_text(json.dumps(records, indent=2) + '\n')
        pd.DataFrame([{k: v for k, v in r.items() if k != 'assignment'} for r in records]).to_csv(
            out / 'front_summary.csv', index=False)
        np.savez_compressed(out / 'front_assignments.npz',
                            assignments=np.array([r['assignment'] for r in records]),
                            parent_names=names, children=data['children'],
                            point_ids=np.array([r['point_id'] for r in records]))
        print(name, result['status'], 'S', round(state, 6), 'worst T/natural', round(worst, 7),
              'gap', result.get('absolute_gap'), 'edges', result.get('active_edges'),
              'seconds', round(result['elapsed_seconds'], 2), flush=True)
        return result

    # A loose state budget gives the pure minimax-travel endpoint. The known
    # single-embryo state endpoint gives the exact shared minimum of state cost.
    loose = float(e.max(axis=0).sum())
    travel_endpoint = point(loose, 'travel_endpoint')
    min_state = min(costs(a, t, e, nt)[1] for a in pool)
    max_state = travel_endpoint['expression']
    budgets = np.linspace(max_state, min_state, intervals + 1)
    # Resolve the small region near nature more finely than the global sweep.
    budgets = np.r_[budgets, ns * (1 - np.arange(-1, 3.01, .25) / 100)]
    budgets = sorted(set(float(b) for b in budgets if min_state <= b <= max_state), reverse=True)
    provenance['budgets'] = budgets
    (out / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    for budget in budgets:
        point(budget, f'budget_{budget:.10f}')
    print('Finished', len(records), 'solves in', out, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=OUT)
    parser.add_argument('--intervals', type=int, default=300)
    parser.add_argument('--seconds', type=float, default=10)
    parser.add_argument('--selftest', action='store_true')
    args = parser.parse_args()
    if args.selftest:
        selftest()
    else:
        run(args.out, args.intervals, args.seconds)
