"""Retry incomplete pooled budgets using all saved feasible assignments.

Keep the initial records and record refinement provenance; regenerate reports
with compare_tracking_travel_metrics.py afterwards. Does not change objectives.
"""
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from terminal_pareto.compare_tracking_travel_metrics import OUT, evaluate, pooled_cost_matrix, source_hashes
from terminal_pareto import common_tracking_front as cf

ORIGINAL_MILP = cf.milp


def strict_milp(*args, **kwargs):
    # Original constraints scale state by its natural total. The default
    # feasibility tolerance can admit >1e-5 raw-state budget overshoot.
    # Tighten the solver tolerance rather than relaxing our replay check.
    kwargs['options'] = dict(kwargs.get('options', {}),
                             mip_feasibility_tolerance=1e-9,
                             primal_feasibility_tolerance=1e-9)
    return ORIGINAL_MILP(*args, **kwargs)


def main():
    cf.milp = strict_milp
    provenance_path = OUT / 'provenance.json'
    provenance = json.loads(provenance_path.read_text())
    assert provenance['sha256'] == source_hashes()
    path = OUT / 'pooled_solver_records.json'
    records = json.loads(path.read_text())
    backup = OUT / 'pooled_solver_records_before_refinement.json'
    if not backup.exists():
        backup.write_bytes(path.read_bytes())
    data, names, cap, t, e, nt, ns, pool = cf.load_problem()
    natural = np.searchsorted(names, data['natural_parents'])
    pool.extend(np.array(r['assignment']) for r in records)
    mean = np.repeat(pooled_cost_matrix(t, nt)[None], 3, axis=0)
    for i, row in enumerate(records):
        if row['status'] == 'optimal':
            continue
        start = time.monotonic()
        result = cf.bounded_solve(mean, e, cap, np.ones(3), ns, row['budget'], pool, 30)
        assignment = np.array(result['assignment'])
        assert np.array_equal(np.bincount(assignment, minlength=len(cap)), cap)
        values = evaluate(assignment, t, e, nt, ns, natural)
        assert values['expression'] <= row['budget'] + 1e-5
        result.update(values, point_id=row['point_id'], budget=row['budget'],
                      elapsed_seconds=time.monotonic() - start, refined=True,
                      initial_status=row['status'])
        records[i] = result
        path.write_text(json.dumps(records, indent=2) + '\n')
        pool.append(assignment)
        print(row['point_id'], result['status'], result.get('absolute_gap'), flush=True)
    provenance['refinement'] = dict(
        source=str(Path(__file__)), source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        initial_records_sha256=hashlib.sha256(backup.read_bytes()).hexdigest(), seconds_per_solver=30,
        mip_feasibility_tolerance=1e-9, primal_feasibility_tolerance=1e-9,
        description='Retry incomplete budgets with tighter feasibility tolerances and all saved feasible assignments')
    provenance_path.write_text(json.dumps(provenance, indent=2) + '\n')
    (OUT / 'refinement_provenance.json').write_text(json.dumps(provenance['refinement'], indent=2) + '\n')
    assert all(r['status'] == 'optimal' for r in records)


if __name__ == '__main__':
    main()
