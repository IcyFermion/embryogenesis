# Pooled-average versus minimax travel: candidate main terminal metrics

Investigation: 2026-09-18. Requested comparison following the dense consensus
front. These are candidate main-analysis choices, not a replacement of the
accepted Figures 2--6, S1--S3, or Table 1. Scope and representation follow
`README.md`; earlier consensus work is in `TRACKING_GEOMETRY_SENSITIVITY.md`.

**Decision update, 2026-09-20:** the author selected pooling as the main travel
metric direction. `POOLED_TRAVEL_MIGRATION_PLAN.md` now defines the staged
implementation and regression/release checks. The comparison below is the
evidence for that decision; production pipelines and accepted figures have
not yet switched. Limited replication is a plausible contributor to unstable
transfer, not a demonstrated explanation of the observed failures.

## Findings and decision context

Both routes are implemented and compared at the **same 319 cell-state
budgets**, with all optimizations certified within numerical tolerances.
The comparison uses the same 275 terminal children, parent capacities, and
protein costs. Minimax results reuse the verified dense checkpoint; pooled
results are newly computed. Each resulting assignment is evaluated unchanged
in all three tracking geometries.

**Pooling is a practical candidate for a main ensemble-average travel metric.**
It remains a sum of edge costs, so the existing Hungarian matching, exact
cousin-null moments, subtree pipeline, and per-edge cost breakdowns apply.
Minimax instead asks for the best worst-embryo result and is a useful companion
sensitivity analysis. Choose between these objectives according to the
scientific question; the fact that one makes natural lineage closer to some
fronts is not itself a reason to prefer it.

The methods differ meaningfully near nature:

| Required cell-state reduction | Pooled: mean travel reduction | Pooled: worst travel reduction | Minimax: mean travel reduction | Minimax: worst travel reduction |
|---|---|---|---|---|
| 0% | 2.984% | -0.127% | 2.334% | 2.276% |
| 0.5% | 2.644% | -1.196% | 1.908% | 1.897% |
| 1% | 2.219% | -0.236% | 1.489% | 1.469% |
| 2% | 1.470% | -2.211% | 0.594% | 0.493% |

Negative reductions mean costs above natural lineage. These percentages refer
to actual optimal assignments, which may use less than the allowed state
budget. Pooled and minimax selected biological parents agree at a median of
86.18% over the budget grid (86.36% over required reductions -1% to 3%).
This is a descriptive grid summary, not uncertainty across independent samples.

### Leave-one-geometry-out check

Each method was fitted to two embryos at required cell-state reductions of
0%, 0.5%, 1%, and 2%, then evaluated in the third. All 24 fits were certified.
Each method lowered held-out travel in only **2 of 12** settings. At the
zero-state-increase budget:

| Excluded embryo | Pooled held-out travel reduction | Minimax held-out travel reduction |
|---|---|---|
| 1 | -2.151% | -3.589% |
| 2 | 0.372% | 0.953% |
| 3 | -3.248% | -2.388% |

Thus fitting all three supports an in-sample ensemble comparison, not a claim
that the optimized edges improve travel in a new embryo. Training uses only
the two retained cost matrices, their native assignments, and assignments
optimized from those matrices. The held-out cost never selects the solution
or seeds its optimization. This diagnostic conditions on the already selected
275-cell intersection and shared protein costs; with three biological embryos,
it is not a population validation or an estimate of isolated tracking error.

## Exact definitions

For a shared assignment \(A\), let \(T_r(A)\) be travel in embryo \(r\),
\(L\) natural lineage, and \(S(A)\) the shared cell-state cost. Define

\[
P(A)=\frac{1}{3}\sum_{r=1}^{3}\frac{T_r(A)}{T_r(L)},
\qquad
R(A)=\max_{r\in\{1,2,3\}}\frac{T_r(A)}{T_r(L)}
\]

Each budget solve minimizes either \(P\) or \(R\), subject to \(S(A)\le b\)
and the original parent capacities. Both natural costs equal one. The
normalization uses the global natural totals 740.845103, 780.637040, and
750.240285, giving embryos equal weight in relative travel cost.

Pooling is exactly represented by the edge matrix

\[
\overline d_{ij}=\frac{1}{3}\sum_{r=1}^{3}\frac{d_{ij}^{(r)}}{T_r(L)}
\]

No coordinates are averaged and no synthetic spatial embryo is constructed.
These are representative-position Euclidean displacements, not integrated
trajectory lengths. The global normalization factors stay fixed when taking
subtree submatrices; renormalizing each subtree separately would change the
relative embryo weights and define a different metric.

For comparison, the unnormalized mean-distance matrix was also run through
the 301-point null-SD-weighted sweep. Its assignments have 99.67% average
biological-parent agreement with normalized pooling at matched weights
(minimum 90.18%). Thus the normalization choice has a modest aggregate effect
here, while individual weights can still change appreciably.

Minimax is a maximum of assignment totals, not a sum of edgewise maxima.
Consequently it cannot generally be passed to the existing analysis as one
fixed edge-cost matrix. In particular, summing separately optimized subtree
maxima would not give the global minimax objective.

## Main-analysis adoption audit

### Coverage and subtree effects

The strict intersection reduces primary embryo-1 coverage from **299 to 275
edges**, retaining 91.97%, and changes the qualifying subtree set from **43
to 42**. `ABpraa` drops below the minimum-12 rule. Both metrics have this
coverage consequence; unevenly averaging whichever replicas happen to cover
each edge would define another missing-data policy and was not used.

The existing canonical pipeline was run on all 42 subtrees, comparing
embryo-1 travel and pooled travel on **identical matched edges**, with 301
weighted solutions and exact cousin-null moments for each. This separates
metric changes from the coverage change:

| Quantity | Embryo 1, shared edges | Pooled, shared edges |
|---|---|---|
| P0 natural-to-front distance, d_LP | 0.020391 | 0.015000 |
| P0 position along front, u_L | 0.259941 | 0.243331 |
| P0 maximum natural-edge retention | 80.73% | 83.27% |
| Subtrees with natural lineage on sampled front | 15 / 42 | 27 / 42 |

Across subtrees, median absolute changes are 0.00963 in d_LP, 0.01666 in u_L,
and 4.08 percentage points in maximum edge retention. These medians conceal
large changes: ABprppp d_LP changes from 0.46912 to zero, ABplpp from 0.51777
to 0.11859, and ABarp from zero to 0.16488. Sampled-front membership changes
in 14 subtrees (13 enter, one leaves). Do not describe adoption as a cosmetic
averaging change or assert that every subtree conclusion is stable. The
subtrees are nested, not independent biological replicates.

### Nulls, decomposition, and remaining migration work

For pooling, exact null moments must be computed **on the pooled matrix**.
This automatically retains cross-embryo covariance induced by the same
shuffled assignment. The global pooled null mean is 1.328343 and SD is
0.036123. Averaging individual standard deviations or treating embryos'
assignment shuffles as independent would be incorrect.

For minimax, the maximum is taken separately for each shared null assignment.
The standard additive exact-moment formula does not apply. A 10,000-draw,
seed-42 shared cousin-shuffle diagnostic gives minimax mean 1.345852 and SD
0.038617; these are sampled estimates, not exact moments or calibrated
rare-tail probabilities. A pooled draw from the same permutations agrees
with the analytic pooled mean/SD to Monte Carlo precision.

The candidate pooled matrix and its child/parent ordering are saved for
integration. Formal primary adoption would require regenerating the main
global, subtree, cell-type, edge-perturbation, and null analyses on the matched
set, then updating figures, table, captions, and manuscript claims together.
Minimax additionally needs explicit treatment of the non-additive objective
in each cost decomposition and robust optimization under each restriction.
This investigation completes the comparison and pooled subtree preflight;
it does not claim that all publication analyses have already been migrated.

## Artifacts and reproduction

Review: `output/tracking_metric_comparison/tracking_metric_comparison_review.pdf`

1. Global fronts under both objectives, parent agreement, and near-natural
   benefit/cost of pooling at matched state budgets.
2. Per-embryo evaluation and leave-one-geometry-out results.
3. Canonical subtree comparison and adoption consequences.

Run from the repository root in the `dev` environment:

```bash
python terminal_pareto/compare_tracking_travel_metrics.py --selftest
python terminal_pareto/compare_tracking_travel_metrics.py
python terminal_pareto/refine_tracking_metric_comparison.py
python terminal_pareto/compare_tracking_travel_metrics.py
python terminal_pareto/tracking_metric_subtree_audit.py
python terminal_pareto/plot_tracking_metric_comparison.py
```

The second comparison invocation replays the refined checkpoint and rebuilds
the derived tables; it does not repeat completed optimizations. The minimax
checkpoint must already exist at `output/common_tracking_assignment/dense_front/`.
Source/cache hashes guard resumption. All new outputs stay under
`output/tracking_metric_comparison/` and are Git-ignored.

Key machine-readable files:

- `candidate_travel_matrices.npz`: normalized and raw pooled matrices, natural
  totals, molecular costs, and the ordered matched edges;
- `pooled_solver_records.json`, `paired_budgets.csv`, `front_evaluations.csv`,
  `headline_comparison.csv`: assignments, certificates, and cross-evaluation;
- `weighted_assignments.npz`, `weighted_fronts.csv`: standard weighted
  pooled/raw-mean sweeps, distinct from the matched-budget comparison;
- `leave_one_out_records.json`, `leave_one_out.csv`: training settings,
  assignments, certificates, and all three evaluation costs;
- `shared_cousin_null.csv`, `diagnostic_summary.json`: common null draws and
  analytic/sampled moment comparison;
- `matched_subtree_metrics.csv`, `matched_subtree_assignments.npz`: both
  canonical runs on the 42 matched subtrees;
- separate analysis, refinement, subtree, and figure provenance manifests.

### Validation and numerical refinement

Twelve small pooled budget problems were checked against exhaustive capacity-
preserving assignment enumeration, together with matrix-aggregation identities.
All final 319 pooled and 319 minimax assignments are certified and replayed
against the original cost matrices, checking parent capacities, state budgets,
travel totals, and bounds. Matched-budget checks confirm pooled mean cost is
no greater than minimax mean cost and minimax worst cost is no greater than
pooled worst cost, within numerical tolerances.

Four initial pooled solves failed validation rather than being accepted as
optima. Retrying with the completed feasible pool resolved one. The remaining
three exceeded the raw-state budget check under HiGHS' default scaled
feasibility tolerance. Refinement tightened primal and integer feasibility
tolerances to 1e-9, retaining the original verification threshold, and all
three then passed with certificates. Original records are preserved as
`pooled_solver_records_before_refinement.json`; the refinement's source,
tolerances, and input hash are recorded separately. The original minimax
solver source and its cache hashes remain unchanged.

Python compilation, whitespace checks, replay validation, and rendered PDF
inspection complete the verification. No accepted publication assets or
manuscript text are overwritten.
