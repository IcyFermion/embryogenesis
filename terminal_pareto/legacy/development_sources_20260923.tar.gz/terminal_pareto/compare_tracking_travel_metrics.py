"""Compare pooled-average and minimax tracking costs on identical assignments/budgets.

Candidate main-analysis metrics only. Writes to a separate review directory.
Run in dev from the repository root. Existing minimax checkpoints are reused.
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import sys
import time

import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from terminal_pareto import common_tracking_front as cf
from terminal_pareto import pareto_engine as pe
from terminal_pareto.subtree_analysis import exact_cousin_stats
from terminal_pareto.tracking_geometry_sensitivity import sweep
from terminal_pareto.figS3_ce_tracking_variance_amendment import load_and_validate

OUT = ROOT / 'terminal_pareto/output/tracking_metric_comparison'
DENSE = cf.OUT


def pooled_cost_matrix(travel, natural_travel):
    """Equal mean of embryo-relative edge distances; fixed global denominators."""
    assert np.all(natural_travel > 0)
    return np.mean(travel / natural_travel[:, None, None], axis=0)


def evaluate(a, t, e, nt, ns, natural):
    travel, state, worst = cf.costs(a, t, e, nt)
    row = dict(expression=float(state), expression_natural=float(ns),
               state_reduction_pct=float(100 * (1 - state / ns)),
               mean_ratio=float(np.mean(travel / nt)), worst_ratio=float(worst),
               mean_reduction_pct=float(100 * (1 - np.mean(travel / nt))),
               worst_reduction_pct=float(100 * (1 - worst)),
               natural_retention=float(np.mean(a == natural)))
    for r, cost, nat in zip(cf.REPS, travel, nt):
        row[r + '_travel'] = float(cost)
        row[r + '_reduction_pct'] = float(100 * (1 - cost / nat))
    return row


def source_hashes():
    paths = [Path(__file__), Path(cf.__file__), cf.CACHE,
             DENSE / 'solver_records.json', DENSE / 'provenance.json',
             ROOT / 'data/cell_lineage.json',
             ROOT / 'terminal_pareto/pareto_engine.py',
             ROOT / 'terminal_pareto/subtree_analysis.py']
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}


def selftest():
    rng = np.random.default_rng(118)
    cap = np.array([2, 1, 1])
    natural = np.array([0, 0, 1, 2])
    assignments = np.unique(list(itertools.permutations(natural)), axis=0)
    for repeat in range(4):
        t = rng.uniform(.1, 2, (3, 3, 4))
        e = rng.uniform(.1, 2, (3, 4))
        nt = t[:, natural, np.arange(4)].sum(axis=1)
        ns = e[natural, np.arange(4)].sum()
        mean = pooled_cost_matrix(t, nt)
        synthetic = np.repeat(mean[None], 3, axis=0)
        states = np.array([cf.costs(a, t, e, nt)[1] for a in assignments])
        for a in assignments:
            np.testing.assert_allclose(mean[a, np.arange(4)].sum(),
                                       np.mean(t[:, a, np.arange(4)].sum(axis=1) / nt))
        for budget in [states.min(), np.median(states), states.max()]:
            feasible = assignments[states <= budget + 1e-10]
            result = cf.solve(synthetic, e, cap, np.ones(3), ns, budget, [feasible[0]], 10)
            actual = mean[np.array(result['assignment']), np.arange(4)].sum()
            truth = min(mean[a, np.arange(4)].sum() for a in feasible)
            np.testing.assert_allclose(actual, truth, atol=1e-7)
            assert result['lower_bound'] <= truth + 1e-7
    print('12 exhaustive pooled budget solves and matrix-aggregation identities passed.', flush=True)


def run(out, seconds):
    out.mkdir(parents=True, exist_ok=True)
    load_and_validate()
    dense_provenance = json.loads((DENSE / 'provenance.json').read_text())
    assert dense_provenance['source_sha256'] == hashlib.sha256(Path(cf.__file__).read_bytes()).hexdigest()
    assert dense_provenance['cache_sha256'] == hashlib.sha256(cf.CACHE.read_bytes()).hexdigest()
    hashes = source_hashes()
    record_path = out / 'pooled_solver_records.json'
    if record_path.exists():
        assert json.loads((out / 'provenance.json').read_text())['sha256'] == hashes, \
            'Source/input changed; preserve checkpoint and choose a new output directory'
    (out / 'provenance.json').write_text(json.dumps(dict(
        sha256=hashes, seconds_per_solver=seconds,
        pooled_definition='mean_r T_r(A)/T_r(L)', minimax_definition='max_r T_r(A)/T_r(L)',
        normalization='Fixed global natural totals, including for subtree submatrices',
        n_matched_edges=275, adopted_as_primary=False), indent=2) + '\n')
    data, names, cap, t, e, nt, ns, pool = cf.load_problem()
    natural = np.searchsorted(names, data['natural_parents'])
    n = len(natural)
    rows = np.arange(n)
    raw = np.array([data[r + '_travel_matrix'] for r in cf.REPS])
    mean_matrix = pooled_cost_matrix(raw, nt)
    unique_mean = pooled_cost_matrix(t, nt)
    synthetic_mean = np.repeat(unique_mean[None], 3, axis=0)
    np.testing.assert_allclose(np.trace(mean_matrix), 1., atol=1e-12)
    robust_records = json.loads((DENSE / 'solver_records.json').read_text())
    for record in robust_records:
        a = np.array(record['assignment'])
        assert record['status'] == 'optimal'
        assert np.array_equal(np.bincount(a, minlength=len(cap)), cap)
        costs = evaluate(a, t, e, nt, ns, natural)
        np.testing.assert_allclose(costs['expression'], record['expression'], atol=1e-8, rtol=0)
        np.testing.assert_allclose(costs['worst_ratio'], record['worst_travel_ratio'], atol=1e-10, rtol=0)
        for r in cf.REPS:
            np.testing.assert_allclose(costs[r + '_travel'], record[r + '_travel'], atol=1e-8, rtol=0)
        pool.append(a)

    lineage = json.loads((ROOT / 'data/cell_lineage.json').read_text())
    groups = pe.build_cousin_groups(data['children'], pe.build_grandparent_map(lineage))
    moments = exact_cousin_stats(mean_matrix, data['expression_matrix'], groups)
    weighted = sweep(mean_matrix, data['expression_matrix'], np.sqrt(moments[2]),
                     np.sqrt(moments[3]), data['natural_parents'], 300)
    weighted_parents = natural[np.argsort(weighted['assignments'], axis=1)]
    pool.extend(weighted_parents)
    pool = list(np.unique(pool, axis=0))
    raw_mean = raw.mean(axis=0)
    raw_moments = exact_cousin_stats(raw_mean, data['expression_matrix'], groups)
    raw_sweep = sweep(raw_mean, data['expression_matrix'], np.sqrt(raw_moments[2]),
                      np.sqrt(raw_moments[3]), data['natural_parents'], 300)
    raw_parents = natural[np.argsort(raw_sweep['assignments'], axis=1)]
    np.savez_compressed(out / 'candidate_travel_matrices.npz', normalized_mean=mean_matrix,
                        raw_mean=raw_mean, natural_travel=nt, children=data['children'],
                        natural_parents=data['natural_parents'], expression=data['expression_matrix'])
    np.savez_compressed(out / 'weighted_assignments.npz', normalized_mean=weighted_parents,
                        raw_mean=raw_parents, alpha=weighted['alpha'], parent_names=names,
                        children=data['children'])
    weighted_rows = []
    for metric, assignments in [('normalized_mean', weighted_parents), ('raw_mean', raw_parents)]:
        for alpha, a in zip(weighted['alpha'], assignments):
            weighted_rows.append(dict(metric=metric, alpha=float(alpha),
                                      **evaluate(a, t, e, nt, ns, natural)))
    pd.DataFrame(weighted_rows).to_csv(out / 'weighted_fronts.csv', index=False)

    saved = json.loads(record_path.read_text()) if record_path.exists() else []
    for r in saved:
        pool.append(np.array(r['assignment']))
    for reference in robust_records:
        point_id = reference['point_id']
        if any(r['point_id'] == point_id for r in saved):
            continue
        start = time.monotonic()
        result = cf.bounded_solve(synthetic_mean, e, cap, np.ones(3), ns,
                                  reference['budget'], pool, seconds)
        a = np.array(result['assignment'])
        costs = evaluate(a, t, e, nt, ns, natural)
        assert np.array_equal(np.bincount(a, minlength=len(cap)), cap)
        assert costs['expression'] <= reference['budget'] + 1e-5
        result.update(costs, point_id=point_id, budget=reference['budget'],
                      elapsed_seconds=time.monotonic() - start)
        saved.append(result)
        pool.append(a)
        record_path.write_text(json.dumps(saved, indent=2) + '\n')
        print(len(saved), point_id, result['status'], 'mean', round(costs['mean_ratio'], 7),
              'worst', round(costs['worst_ratio'], 7), flush=True)
    assert len(saved) == len(robust_records)
    paired, fronts = [], []
    for reference, result in zip(robust_records, saved):
        assert reference['point_id'] == result['point_id']
        robust = evaluate(np.array(reference['assignment']), t, e, nt, ns, natural)
        pooled = evaluate(np.array(result['assignment']), t, e, nt, ns, natural)
        if result['status'] == 'optimal':
            assert pooled['mean_ratio'] <= robust['mean_ratio'] + 1e-7
        assert robust['worst_ratio'] <= pooled['worst_ratio'] + 1e-7
        agreement = np.mean(np.array(reference['assignment']) == np.array(result['assignment']))
        pair = dict(point_id=result['point_id'], budget=result['budget'],
                    required_state_reduction_pct=100 * (1 - result['budget'] / ns),
                    parent_agreement=float(agreement), pooled_status=result['status'],
                    mean_advantage_pp=100 * (robust['mean_ratio'] - pooled['mean_ratio']),
                    worst_disadvantage_pp=100 * (pooled['worst_ratio'] - robust['worst_ratio']))
        for metric, values in [('pooled', pooled), ('minimax', robust)]:
            pair.update({metric + '_' + k: v for k, v in values.items()})
            fronts.append(dict(metric=metric, point_id=result['point_id'],
                               budget=result['budget'], **values))
        paired.append(pair)
    pd.DataFrame(paired).to_csv(out / 'paired_budgets.csv', index=False)
    pd.DataFrame(fronts).to_csv(out / 'front_evaluations.csv', index=False)

    # Same null assignment in every geometry: replicate evaluations are correlated.
    rng = np.random.default_rng(42)
    permutations = np.tile(rows, (10000, 1))
    for group in groups:
        group = np.array(group)
        permutations[:, group] = np.take(group, np.argsort(rng.random((len(permutations), len(group))), axis=1))
    null_ratios = np.array([matrix[rows, permutations].sum(axis=1) / nat
                            for matrix, nat in zip(raw, nt)]).T
    null_state = data['expression_matrix'][rows, permutations].sum(axis=1)
    null = pd.DataFrame(dict(pooled=null_ratios.mean(axis=1), minimax=null_ratios.max(axis=1),
                             expression=null_state))
    null.to_csv(out / 'shared_cousin_null.csv', index=False)
    stats = dict(pooled_mean_exact=moments[0], pooled_sd_exact=np.sqrt(moments[2]),
                 state_mean_exact=moments[1], state_sd_exact=np.sqrt(moments[3]),
                 minimax_mean_sampled=float(null.minimax.mean()),
                 minimax_sd_sampled=float(null.minimax.std(ddof=0)), null_draws=len(null),
                 pooled_sample_mean=float(null.pooled.mean()),
                 pooled_sample_sd=float(null.pooled.std(ddof=0)),
                 normalization_parent_agreement_mean=float(np.mean(raw_parents == weighted_parents)),
                 normalization_parent_agreement_min=float(np.min(np.mean(raw_parents == weighted_parents, axis=1))))
    (out / 'diagnostic_summary.json').write_text(json.dumps(stats, indent=2) + '\n')
    leave_one_out(out, data, names, cap, t, e, nt, ns, natural, seconds)
    print('Comparison complete:', out, flush=True)


def leave_one_out(out, data, names, cap, t, e, nt, ns, natural, seconds):
    """Training uses only the two retained geometries; fixed shared cell set/state."""
    path = out / 'leave_one_out_records.json'
    records = json.loads(path.read_text()) if path.exists() else []
    for held in range(3):
        train = [r for r in range(3) if r != held]
        pool = [natural]
        for r in train:
            pool.extend(natural[np.argsort(a)] for a in data[cf.REPS[r] + '_assignments'])
        mean = pooled_cost_matrix(t[train], nt[train])
        expanded = np.repeat(np.arange(len(cap)), cap)
        for alpha in np.linspace(0, 1, 101):
            rows, cols = linear_sum_assignment(alpha * mean[expanded] + (1 - alpha) * e[expanded] / ns)
            a = np.empty(e.shape[1], dtype=int)
            a[cols] = expanded[rows]
            pool.append(a)
        base_pool = list(np.unique(pool, axis=0))
        for metric in ['pooled', 'minimax']:
            pool = base_pool.copy()
            # Duplicate one training scenario to use the existing 3-scenario
            # solver. Duplicating a scenario leaves a maximum unchanged.
            train_cost = (np.repeat(mean[None], 3, axis=0) if metric == 'pooled' else
                          t[[train[0], train[1], train[1]]] / nt[[train[0], train[1], train[1]], None, None])
            for reduction in [0., .5, 1., 2.]:
                key = f'{held}_{metric}_{reduction}'
                old = next((row for row in records if row['key'] == key), None)
                if old is not None:
                    pool.append(np.array(old['assignment']))
                    continue
                budget = ns * (1 - reduction / 100)
                result = cf.bounded_solve(train_cost, e, cap, np.ones(3), ns, budget, pool, seconds)
                a = np.array(result['assignment'])
                values = evaluate(a, t, e, nt, ns, natural)
                assert values['expression'] <= budget + 1e-5
                assert np.array_equal(np.bincount(a, minlength=len(cap)), cap)
                result.update(values, key=key, metric=metric, held_out=cf.REPS[held],
                              required_state_reduction_pct=reduction,
                              held_out_reduction_pct=values[cf.REPS[held] + '_reduction_pct'])
                records.append(result)
                pool.append(a)
                path.write_text(json.dumps(records, indent=2) + '\n')
                print('LOO', key, result['status'], 'held-out saving',
                      round(result['held_out_reduction_pct'], 4), flush=True)
    pd.DataFrame([{k: v for k, v in row.items() if k != 'assignment'} for row in records]).to_csv(
        out / 'leave_one_out.csv', index=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=OUT)
    parser.add_argument('--seconds', type=float, default=10)
    parser.add_argument('--selftest', action='store_true')
    args = parser.parse_args()
    if args.selftest:
        selftest()
    else:
        run(args.out, args.seconds)
