"""Render the pooled/minimax comparison and main-analysis adoption audit."""
import hashlib
import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from terminal_pareto.compare_tracking_travel_metrics import OUT, DENSE, cf, evaluate, source_hashes

COLORS = {'pooled': '#237CA1', 'minimax': '#793879'}
LABELS = {'pooled': 'Pooled-average assignments', 'minimax': 'Minimax assignments'}


def style(ax, title):
    ax.set_title(title, loc='left', fontsize=10, pad=10)
    ax.spines[['top', 'right']].set_visible(False)
    ax.tick_params(labelsize=8)


def heading(fig, title, subtitle):
    fig.suptitle(title, fontsize=16, y=.98)
    fig.text(.52, .935, subtitle, ha='center', fontsize=10, color='#555555')


def natural(ax):
    ax.axhline(0, lw=.7, ls=':', color='#999999')
    ax.axvline(0, lw=.7, ls=':', color='#999999')
    ax.scatter([0], [0], marker='+', color='#222222', s=70, zorder=5)


def validate():
    provenance = json.loads((OUT / 'provenance.json').read_text())
    assert provenance['sha256'] == source_hashes()
    data, names, cap, t, e, nt, ns, pool = cf.load_problem()
    natural_parent = np.searchsorted(names, data['natural_parents'])
    for metric, path in [('pooled', OUT / 'pooled_solver_records.json'),
                         ('minimax', DENSE / 'solver_records.json')]:
        for row in json.loads(path.read_text()):
            a = np.array(row['assignment'])
            assert np.array_equal(np.bincount(a, minlength=len(cap)), cap)
            result = evaluate(a, t, e, nt, ns, natural_parent)
            assert result['expression'] <= row['budget'] + 1e-5
            assert row['status'] == 'optimal' and row['absolute_gap'] < 1e-7
            objective = result['mean_ratio' if metric == 'pooled' else 'worst_ratio']
            np.testing.assert_allclose(objective, row['lower_bound'], atol=1e-7, rtol=0)
            for r in cf.REPS:
                np.testing.assert_allclose(result[r + '_travel'], row[r + '_travel'], atol=1e-8, rtol=0)
    for row in json.loads((OUT / 'leave_one_out_records.json').read_text()):
        a = np.array(row['assignment'])
        assert np.array_equal(np.bincount(a, minlength=len(cap)), cap)
        result = evaluate(a, t, e, nt, ns, natural_parent)
        assert result['expression'] <= ns * (1 - row['required_state_reduction_pct'] / 100) + 1e-5
        assert row['status'] == 'optimal' and row['absolute_gap'] < 1e-7
        np.testing.assert_allclose(result[row['held_out'] + '_reduction_pct'], row['held_out_reduction_pct'])
    for path in ['subtree_audit_provenance.json']:
        for name, digest in json.loads((OUT / path).read_text()).items():
            assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest


def render():
    validate()
    fronts = pd.read_csv(OUT / 'front_evaluations.csv')
    pair = pd.read_csv(OUT / 'paired_budgets.csv').sort_values('required_state_reduction_pct')
    loo = pd.read_csv(OUT / 'leave_one_out.csv')
    sub = pd.read_csv(OUT / 'matched_subtree_metrics.csv')
    audit = json.loads((OUT / 'subtree_audit_summary.json').read_text())
    stats = json.loads((OUT / 'diagnostic_summary.json').read_text())
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9,
                         'axes.labelsize': 9, 'pdf.fonttype': 42})
    figures = []
    fig, axes = plt.subplots(2, 3, figsize=(12.5, 8.3))
    fig.subplots_adjust(left=.07, right=.98, bottom=.14, top=.84, hspace=.47, wspace=.34)
    heading(fig, 'Pooled-average versus worst-embryo travel cost',
            '275 shared terminal edges | identical cell-state budgets | 319 certified solves per method')
    handles = [Line2D([], [], color=c, lw=2, label=LABELS[k]) for k, c in COLORS.items()]
    handles.append(Line2D([], [], marker='+', ls='', color='#222222', label='Natural lineage'))
    fig.legend(handles=handles, loc='upper center', bbox_to_anchor=(.52, .902), ncol=3, frameon=False)
    for col, measure in enumerate(['mean_ratio', 'worst_ratio']):
        for row in [0, 1]:
            ax = axes[row, col]
            for metric, color in COLORS.items():
                frame = fronts[fronts.metric == metric].sort_values('expression').drop_duplicates(
                    ['expression', 'mean_ratio', 'worst_ratio'])
                ax.plot(-frame.state_reduction_pct, 100 * (frame[measure] - 1),
                        color=color, lw=1.4, marker='.' if row else None, ms=2.8,
                        ls='-' if metric == 'pooled' else '--')
            natural(ax)
            name = 'Mean' if col == 0 else 'Worst-embryo'
            style(ax, f'{"AB"[col] if row == 0 else "DE"[col]}  {name} travel' + (' near nature' if row else ''))
            ax.set(xlabel='Cell-state change from natural (%)', ylabel=f'{name} travel change (%)')
            if row:
                ax.set(xlim=(-3.2, 1.1), ylim=(-4.5, 3.2))
                ax.add_patch(Rectangle((-3.2, -4.5), 3.2, 4.5, fc='#E9F2E9', ec='none', zorder=0))
    ax = axes[0, 2]
    show = pair[pair.required_state_reduction_pct > -50]
    ax.plot(show.required_state_reduction_pct, 100 * show.parent_agreement, color='#666666', lw=1.2)
    style(ax, 'C  Agreement in assigned parents')
    ax.set(xlabel='Required cell-state reduction (%)', ylabel='Biological-parent agreement (%)', ylim=(0, 102))
    ax = axes[1, 2]
    local = pair[pair.required_state_reduction_pct.between(-1.01, 3.01)]
    ax.plot(local.required_state_reduction_pct, local.mean_advantage_pp, color=COLORS['pooled'],
            lw=1.4, label='Mean saving gained by pooling')
    ax.plot(local.required_state_reduction_pct, local.worst_disadvantage_pp, color='#B87528',
            lw=1.4, label='Worst-embryo saving lost')
    style(ax, 'F  Pooling benefit and cost')
    ax.set(xlabel='Required cell-state reduction (%)', ylabel='Difference (percentage points)')
    ax.legend(frameon=False, fontsize=7.5, loc='upper left')
    fig.text(.07, .075, 'Both methods assign the same 275 children once; only the aggregation of embryo-specific travel costs changes.', fontsize=9)
    fig.text(.07, .045, 'Cross-evaluated curves need not be optimal for the displayed metric. Lines connect sampled feasible assignments; they are visual guides.', fontsize=8.5)
    figures.append(fig)

    fig, axes = plt.subplots(2, 3, figsize=(12.5, 8.3))
    fig.subplots_adjust(left=.07, right=.98, bottom=.15, top=.84, hspace=.48, wspace=.31)
    heading(fig, 'Shared improvements depend on which geometries are fitted',
            'Top: all three embryos used for optimization | Bottom: fit two, evaluate the excluded embryo')
    fig.legend(handles=handles[:2], loc='upper center', bbox_to_anchor=(.52, .902), ncol=2, frameon=False)
    for col, r in enumerate(cf.REPS):
        ax = axes[0, col]
        for metric, color in COLORS.items():
            frame = fronts[fronts.metric == metric].sort_values('expression').drop_duplicates(['expression', r + '_reduction_pct'])
            ax.plot(-frame.state_reduction_pct, -frame[r + '_reduction_pct'], color=color,
                    lw=1.2, marker='.', ms=2.5, ls='-' if metric == 'pooled' else '--')
        natural(ax)
        ax.set(xlim=(-3.2, .6), ylim=(-8, 5), xlabel='Cell-state change from natural (%)', ylabel='Travel change from natural (%)')
        ax.add_patch(Rectangle((-3.2, -8), 3.2, 8, fc='#E9F2E9', ec='none', zorder=0))
        style(ax, f'{chr(65 + col)}  Evaluated in embryo {col + 1}')
        ax = axes[1, col]
        for metric, color in COLORS.items():
            frame = loo[(loo.metric == metric) & (loo.held_out == r)].sort_values('required_state_reduction_pct')
            ax.plot(frame.required_state_reduction_pct, frame.held_out_reduction_pct,
                    color=color, lw=1.4, marker='o', ms=4, ls='-' if metric == 'pooled' else '--')
        ax.axhline(0, color='#555555', ls=':', lw=.9)
        style(ax, f'{chr(68 + col)}  Embryo {col + 1} excluded from fitting')
        ax.set(xlabel='Required cell-state reduction (%)', ylabel='Held-out travel reduction (%)', ylim=(-6.5, 1.5), xticks=[0, .5, 1, 2])
    fig.text(.07, .08, 'Positive reduction means travel below natural lineage. Each method improves held-out travel in only 2 of 12 tested settings.', fontsize=9)
    fig.text(.07, .047, 'All 24 two-embryo optimizations were certified. This diagnostic holds the 275-cell intersection and protein costs fixed; it is not population validation.', fontsize=8.5)
    figures.append(fig)

    fig, axes = plt.subplots(1, 3, figsize=(12.5, 7.7))
    fig.subplots_adjust(left=.07, right=.98, bottom=.43, top=.83, wspace=.35)
    heading(fig, 'Adoption check for the main terminal-only analysis',
            'Pooled costs through the existing canonical pipeline | 42 matched subtrees | 301 weighted solutions per subtree')
    for ax, key, label, letter in zip(axes, ['d_lp', 'u_lineage_lp', 'max_er'],
                                    ['Natural-to-front distance', 'Position along front', 'Maximum natural-edge retention'], 'ABC'):
        wide = sub.pivot(index='subtree', columns='metric', values=key)
        ax.scatter(wide.embryo1_matched, wide.pooled, color=COLORS['pooled'], s=23, alpha=.8)
        low, high = min(wide.min()), max(wide.max())
        margin = max(.005, (high - low) * .08)
        ax.plot([low - margin, high + margin], [low - margin, high + margin], color='#999999', ls=':', lw=.8)
        labels = (['P0', 'ABprppp', 'ABplpp', 'ABarp'] if key == 'd_lp' else
                  ['P0', 'P1'] if key == 'u_lineage_lp' else ['P0', 'AB', 'ABa', 'ABp', 'P1'])
        for name in labels:
            if name in wide.index:
                point = wide.loc[name]
                offset = (-6, 7) if name in ['ABprppp', 'ABplpp'] else (5, 5)
                ax.annotate(name, (point.embryo1_matched, point.pooled), xytext=offset,
                            textcoords='offset points', fontsize=7,
                            ha='right' if offset[0] < 0 else 'left')
        style(ax, f'{letter}  {label}')
        ax.set(xlabel='Embryo 1 on shared edges', ylabel='Pooled average on shared edges')
    lines = [
        'Coverage: 299 to 275 primary edges (24 excluded); 43 to 42 qualifying subtrees.',
        'Natural lineage on the sampled front: 15 / 42 with embryo-1 travel; 27 / 42 with pooling. Some subtree changes are substantial.',
        f'Median absolute changes: distance {audit["d_lp_median_absolute_change"]:.4f}; '
        f'front position {audit["u_median_absolute_change"]:.4f}; '
        f'maximum retention {100 * audit["retention_median_absolute_change"]:.2f} percentage points.',
        'Pooled metric: one additive distance matrix; existing matching, exact cousin-null moments, and edge-cost breakdowns remain applicable.',
        'Minimax metric: a maximum of three assignment totals; requires robust optimization and a joint null, with no additive edge-cost breakdown.',
        'Global normalization factors remain fixed for every subtree. The scatter separates metric effects from the change in edge coverage.',
        'Candidate use: pooled average as the main ensemble metric, minimax as a sensitivity analysis. Publication outputs are not replaced.'
    ]
    for i, line in enumerate(lines):
        fig.text(.07, .34 - .040 * i, line, fontsize=8.8, color='#333333')
    figures.append(fig)

    with PdfPages(OUT / 'tracking_metric_comparison_review.pdf') as pdf:
        for i, fig in enumerate(figures, 1):
            pdf.savefig(fig)
            fig.savefig(OUT / f'tracking_metric_comparison_page{i}.png', dpi=170)
            plt.close(fig)
    highlights = pair[np.isclose(pair.required_state_reduction_pct.to_numpy()[:, None], [0, .5, 1, 2], atol=1e-9).any(axis=1)]
    highlights.to_csv(OUT / 'headline_comparison.csv', index=False)
    summary = dict(pooled_budget_solves=len(pair), pooled_certified=int((pair.pooled_status == 'optimal').sum()),
                   biological_parent_agreement_median=float(pair.parent_agreement.median()),
                   local_parent_agreement_median=float(local.parent_agreement.median()),
                   holdout_positive_counts={metric: int((loo[loo.metric == metric].held_out_reduction_pct > 0).sum()) for metric in COLORS},
                   normalization_comparison=stats, subtree_audit=audit)
    summary['subtree_natural_on_sampled_front'] = sub.groupby('metric').natural_on_grid.sum().astype(int).to_dict()
    (OUT / 'comparison_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    inputs = [Path(__file__)] + [OUT / file for file in [
        'paired_budgets.csv', 'front_evaluations.csv', 'leave_one_out.csv', 'matched_subtree_metrics.csv',
        'subtree_audit_summary.json', 'diagnostic_summary.json', 'provenance.json', 'refinement_provenance.json']]
    (OUT / 'figure_provenance.json').write_text(json.dumps(
        {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    render()
